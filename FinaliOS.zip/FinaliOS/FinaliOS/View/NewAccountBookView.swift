//
//  NewAccountBookView.swift
//  FinaliOS
//
//  Created by MILab on 2023/5/20.
//

import SwiftUI

struct NewAccountBookView: View {
    
    @Environment(\.dismiss) var dismiss
    @Environment(\.managedObjectContext) private var viewContext
    
//    @ObservedObject var accountbook: AccountBook
    @ObservedObject private var accountBookFromModel: AccountBookFromModel
    
    init(){
        let viewModel = AccountBookFromModel()
        viewModel.money = 0
        accountBookFromModel = viewModel
    }
    
    
    @State var Name: [String] = ["伙食", "交通", "玩樂", "收入"]
    @State private var selectedType: Int!
    var body: some View {
        NavigationView{
            VStack{
                VStack {
                    HStack {
                        ForEach(0..<Name.count, id: \.self) { btn in
                            Button(action: {
                                self.selectedType = btn
                                accountBookFromModel.type = self.Name[btn]
                            }) {
                                Text("\(self.Name[btn])")
                                    .padding()
                                    .font(.system(size: 26, weight: .bold, design: .rounded))
                                    .foregroundColor(.white)
                                    .frame(width: 88)
                                    .background(self.selectedType == btn ? Color.teal : Color.green)
                                    .animation(.linear, value: selectedType)
                                    .clipShape(Capsule())
                            }
                        }
                    }
                    
                    Button(action: {
                        self.selectedType = nil
                        accountBookFromModel.type = ""
                    }) {
                        Text("重新選擇")
                    }
                }
                
                
                TextField("", value: $accountBookFromModel.money, formatter: NumberFormatter())
                    .keyboardType(.numberPad)
                    .frame(width: 230, height: 30)
                    .font(.title2)
                    .padding(10)
                    .overlay(
                        RoundedRectangle(cornerRadius: 7)
                            .stroke(Color(.systemTeal), lineWidth: 2.5)
                    )
                
                DatePicker("", selection: $accountBookFromModel.dtstring)
                    .labelsHidden()
                    .environment(\.locale, Locale(identifier: "zh_hant_TW"))
                
                TextField("", text: $accountBookFromModel.remark)
                    .frame(width: 250, height: 110)
                    .font(.subheadline)
                    .padding(10)
                    .overlay(
                        RoundedRectangle(cornerRadius: 9)
                            .stroke(Color(.systemTeal), lineWidth: 3)
                    )
    
                Spacer()
            }
                       
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: {
                        dismiss()
                    }) {
                        Image(systemName: "xmark")
                            .foregroundColor(.red)
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: {
                        save()
                        dismiss()
                    }) {
                        Text("儲存")
                            .font(.headline)
                    }.disabled(accountBookFromModel.money <= 0)
                }
            }
            .navigationTitle("新增紀錄")
        }
    }
    
    private func save() {
        let accountbook = AccountBook(context: viewContext)
        
        accountbook.money = accountBookFromModel.money
        accountbook.dtstring = accountBookFromModel.dtstring
        accountbook.type = accountBookFromModel.type
        accountbook.remark = accountBookFromModel.remark
        
        do {
            try viewContext.save()
        }
        catch {
            print("Failed to save the record...")
            print(error.localizedDescription)
        }
    }
}


struct NewAccountBookView_Previews: PreviewProvider {
    static var previews: some View {
        NewAccountBookView()
    }
}
