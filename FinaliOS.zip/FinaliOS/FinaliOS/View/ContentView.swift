//
//  ContentView.swift
//  FinaliOS
//
//  Created by MILab on 2023/5/11.
//

import SwiftUI
import CoreData



struct ContentView: View {
    
    @FetchRequest(
        entity: AccountBook.entity(), sortDescriptors: [NSSortDescriptor(keyPath: \AccountBook.dtstring, ascending: true)])
    var accountBooks: FetchedResults<AccountBook>
    
    @State private var showNewAccountBook = false
    @State private var showPieOne = false
    @State private var showPieTwo = false
    @State private var showPieThr = false
    
    @Environment(\.managedObjectContext) var context
    
    var body: some View {
        TabView {
            NavigationView {
                ScrollView(.vertical, showsIndicators: false) {
                    VStack {
                        HStack {
                            mRect(mNum: 0, mArray: accountBooks)
                            mRect(mNum: 1, mArray: accountBooks)
                            mRect(mNum: 2, mArray: accountBooks)
                            Button(action: {
                                self.showNewAccountBook = true
                            }) {
                                Image(systemName: "plus.square.fill")
                                    .foregroundColor(.blue)
                                    .font(.system(size: 38))
                            }
                        }
                        if accountBooks.count == 0 {
                            Text("暫無資料")
                                .font(.system(size: 26, design: .rounded))
                                .foregroundColor(.brown)
                                .padding()
                                .overlay(
                                    RoundedRectangle(cornerRadius: 7)
                                        .stroke(Color(.systemGray4), lineWidth: 2.5)
                                )
                                .padding()
                                .onTapGesture {
                                    showNewAccountBook = true
                                }
                            Spacer()
                        } else {
                            
                            
                            ForEach(accountBooks.indices, id: \.self){ index in
                                NavigationLink(destination: UpdItemView(item: accountBooks[index])){
                                    HStack {
                                        Circle()
                                            .frame(width: 70)
                                            .foregroundColor(accountBooks[index].type == "收入" ? .green : Color(.systemGray4))
                                            .overlay(
                                                Text("\(accountBooks[index].type!)")
                                                    .foregroundColor(accountBooks[index].type == "收入" ? .white : .white)
                                                    .font(.system(size: 24))
                                            )
                                        VStack (alignment: .trailing) {
                                            Text("\(accountBooks[index].money)")
                                                .font(.system(size: 34))

                                            Text(accountBooks[index].dtstring!, formatter: DateFormat)
                                                .font(.subheadline)
                                        }
                                        .frame(width: 215, height: 65)
                                        .background(Color(.systemGray5)).cornerRadius(8).padding()
                                    }
                                }
                                
                            }
//                            .onDelete(perform: deleteRecord)
                            Spacer()
                        }
                    }
                }
                
                Button(action: {
                    self.showNewAccountBook = true
                }) {
                    Image(systemName: "plus.rectangle.fill")
                        .foregroundColor(.red)
                        .font(.system(size: 28))
                }.tabItem{Label("新增", systemImage: "plus")}
                
                
            }.tabItem{Label("總覽", systemImage: "house.fill")}
                .sheet(isPresented: $showNewAccountBook) {
                NewAccountBookView()
            }
            
            VStack {
                let one = (b(MoneyArray: accountBooks)[0])*360 / (Double(a(MoneyArray: accountBooks)[1]))
                let two = (b(MoneyArray: accountBooks)[1])*360 / (Double(a(MoneyArray: accountBooks)[1]))
                let thr = (b(MoneyArray: accountBooks)[2])*360 / (Double(a(MoneyArray: accountBooks)[1]))
                ZStack(alignment: .center) {
                    Path(){path in
                        path.move(to: CGPoint(x: 125, y: 125))
                        path.addArc(center: .init(x: 125, y: 125), radius: 125,
                                    startAngle: .degrees(0), endAngle: .degrees(one),
                                    clockwise: false)
                    }.fill(showPieOne ? Color(.systemGray4) : Color.yellow).animation(.linear(duration: 3), value: showPieOne)
                    
                    Path(){path in
                        path.move(to: CGPoint(x: 125, y: 125))
                        path.addArc(center: .init(x: 125, y: 125), radius: 125,
                                    startAngle: .degrees(one), endAngle: .degrees(one+two),
                                    clockwise: false)
                    }.fill(showPieTwo ? Color(.systemGray4) : Color.green).animation(.linear(duration: 3), value: showPieTwo)

                    Path(){path in
                        path.move(to: CGPoint(x: 125, y: 125))
                        path.addArc(center: .init(x: 125, y: 125), radius: 125,
                                    startAngle: .degrees(one+two), endAngle: .degrees(one+two+thr),
                                    clockwise: false)
                    }.fill(showPieThr ? Color(.systemGray4) : Color.teal).animation(.linear(duration: 3), value: showPieThr)
                }.frame(width: 250, height: 250, alignment: .top)
                
                HStack {
                    HStack {
                        Circle()
                            .frame(width: 28).foregroundColor(.yellow)
                        Text("伙食")
                        
                        ZStack{
                            Circle()
                                .stroke(Color(.systemGray5), lineWidth: 10)
                                .frame(width: 100, height: 100)
                            Circle()
                                .trim(from:0.75,to:0.75+0.1)
                                .stroke(Color.green,lineWidth: 10)
                                .frame(width: 100, height: 100)
                            Circle()
//                                .trim(from:0.75,to:1)
                                .trim(from:0,to:(0.75+0.1)-1)
                                .stroke(Color.green,lineWidth: 10)
                                .frame(width: 100, height: 100)
                        }
                    }
                    .onTapGesture {
                        showPieOne.toggle()
                    }
                    
                    HStack {
                        Circle()
                            .frame(width: 28).foregroundColor(.green)
                        Text("交通")
                    }
                    .onTapGesture {
                        showPieTwo.toggle()
                    }
                    
                    
                    HStack {
                        Circle()
                            .frame(width: 28).foregroundColor(.teal)
                        Text("玩樂")
                    }
                    .onTapGesture {
                        showPieThr.toggle()
                    }
                }
                Spacer()
            }.tabItem{Label("統計圖表", systemImage: "chart.pie.fill")}
        }
    }
    
    private func deleteRecord(indexSet: IndexSet) {
        
        for index in indexSet {
            let itemToDelete = accountBooks[index]
            context.delete(itemToDelete)
        }

        DispatchQueue.main.async {
            do {
                try context.save()

            } catch {
                print(error)
            }
        }
    }
}


private let DateTimeFormat: DateFormatter = {
    let formatter = DateFormatter()
    formatter.dateFormat = "yyyy/MM/dd"     //formatter.dateStyle = .short
    formatter.dateFormat += " HH:mm:ss"     //formatter.timeStyle = .medium
    return formatter
}()

private let DateFormat: DateFormatter = {
    let formatter = DateFormatter()
    formatter.dateFormat = "M月d日"
    return formatter
}()

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct mRect: View {
    
    let mNum: Int
    let mArray: FetchedResults<AccountBook>
    
    var mItem: [String] = ["收入", "支出", "總計"]
    
    var body: some View{
        Rectangle()
            .frame(width: 90, height: 70)
            .foregroundColor(Color(.systemGray6))
            .cornerRadius(8)
            .overlay(
                VStack{
                    Text(mItem[mNum])
                    Text("\(a(MoneyArray: mArray)[mNum])")
                }
            )
    }
}

