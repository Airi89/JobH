//
//  UpdItemView.swift
//  FinaliOS
//
//  Created by MILab on 2023/6/7.
//

import SwiftUI
import CoreData

struct UpdItemView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.dismiss) var dismiss
    
    @State var money: String = ""
    @State var isFailed = false
    @State var item: AccountBook
    
    var body: some View {
        VStack {
            Text("金額: \(item.money)")
                .font(.title)
            HStack {
                Text("修改: ")
                    .font(.title3)
                TextField("", text: $money)
                    .textFieldStyle(.roundedBorder)
                    .keyboardType(.decimalPad)
                    .font(.title)
            }
            .padding()
            Button(action: {
                updItem(viewContext: viewContext, item: item, money: Int32(money)!)
                dismiss()
            }, label: { Text("Change cost") })
            .padding()
            .frame(width: 200)
            .foregroundColor(.white)
            .background(.red)
            .font(.title)
            .cornerRadius(12)
            Spacer()
        }
        
        
    }
    func updItem(viewContext: NSManagedObjectContext, item: AccountBook, money: Int32) {
        item.money = money
        do {
            try viewContext.save()
        } catch {
            let nsError = error as NSError
            fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
        }
    }
}

/*
struct UpdItemView_Previews: PreviewProvider {
    static var previews: some View {
        UpdItemView()
    }
}
*/
