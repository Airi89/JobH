//
//  FinaliOSApp.swift
//  FinaliOS
//
//  Created by MILab on 2023/5/11.
//

import SwiftUI

@main
struct FinaliOSApp: App {
    let persistenceController = PersistenceController.shared
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
