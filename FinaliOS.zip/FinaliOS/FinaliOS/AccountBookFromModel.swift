//
//  ExtryBookFromModel.swift
//  FinaliOS
//
//  Created by MILab on 2023/5/18.
//

import Foundation
import Combine

class AccountBookFromModel: ObservableObject {
    
    @Published var money: Int32 = 0
    @Published var type: String = ""
    @Published var remark: String = ""
    @Published var dtstring: Date = Date.now
    
    init(accountBook: AccountBook? = nil) {
        if let accountBook = accountBook{
            self.money = accountBook.money
            self.type = accountBook.type ?? ""
            self.remark = accountBook.remark ?? ""
            self.dtstring = accountBook.dtstring ?? Date.now
        }
    }
}
