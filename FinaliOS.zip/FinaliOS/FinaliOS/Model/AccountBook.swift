//
//  AccountBook.swift
//  FinaliOS
//
//  Created by MILab on 2023/5/20.
//

import Combine
import CoreData

public class accountbook: NSManagedObject{
    @NSManaged public var money: Int32
    @NSManaged public var type: String
    @NSManaged public var remark: String
    @NSManaged public var dtstring: Date
}
