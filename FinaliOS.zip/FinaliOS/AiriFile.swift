//
//  AiriFile.swift
//  FinaliOS
//
//  Created by MILab on 2023/5/20.
//

import SwiftUI
import Foundation

func a(MoneyArray: FetchedResults<AccountBook>) -> [Int32]{
    
    var iMoney: Int32 = 0
    var eMoney: Int32 = 0
    var sumMoney: Int32 = 0
    
    if MoneyArray.count == 0 {
        return [0, 0, 0]
    } else {
        for i in 0...MoneyArray.count-1 {
            if MoneyArray[i].type != "收入" {
                eMoney += MoneyArray[i].money
            } else {
                iMoney += MoneyArray[i].money
            }
        }
        sumMoney = iMoney - eMoney
    }
    
    return [iMoney, eMoney, sumMoney]
}

func b(MoneyArray: FetchedResults<AccountBook>) -> [Double]{
    
    var eMoney: Int32 = 0
    var tMoney: Int32 = 0
    var pMoney: Int32 = 0
    var aMoney: Int32 = 0
    
    if MoneyArray.count == 0 {
        return [0, 0, 0]
    } else {
        for i in 0...MoneyArray.count-1 {
            switch MoneyArray[i].type {
                case "伙食":
                    eMoney += MoneyArray[i].money
                case "交通":
                    tMoney += MoneyArray[i].money
                case "玩樂":
                    pMoney += MoneyArray[i].money
                default:
                    aMoney += MoneyArray[i].money
            }  
        }
    }
    
    return [Double(eMoney), Double(tMoney), Double(pMoney), Double(aMoney)]
}



