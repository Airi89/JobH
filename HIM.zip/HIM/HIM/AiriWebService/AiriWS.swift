import Foundation
import SwiftUI
//import SWXMLHash

public class AiriWS{
    public var Url: String = "http://120.125.78.208:81/WebService1.asmx"
    public var Host: String = "120.125.78.208"//
    public func dataToBase64(data: NSData)->String{
        
        let result = data.base64EncodedString(options: NSData.Base64EncodingOptions.init(rawValue: 0))
        return result;
    }
    public func dataToBase64(data: Data)->String {
        let result = data.base64EncodedString()
        return result
    }
    public func byteArrayToBase64(data:[UInt])->String{
        let nsdata = NSData(bytes: data, length: data.count)
        let data  = Data.init(referencing: nsdata)
        if let str = String.init(data: data, encoding: String.Encoding.utf8){
            return str
        }
        return "";
    }
    public func timeToString(date: Date)->String{
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "HH:mm:ss"
        let dateString = dateFormatter.string(from: date)
        return dateString
    }
    public func dateToString(date: Date)->String{
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let dateString = dateFormatter.string(from: date)
        return dateString
    }
    public func base64ToByteArray(base64String: String) -> [UInt8] {
        let data = Data.init(base64Encoded: base64String)
        let dataCount = data!.count
        var bytes = [UInt8].init(repeating: 0, count: dataCount)
        data!.copyBytes(to: &bytes, count: dataCount)
        return bytes
    }
    
    
    func stringFromXML(data: Data)-> String
    {
        let xmlToParse: String? = String.init(data: data, encoding: String.Encoding.utf8)
        
        if xmlToParse == nil {
            return ""
        }
        if xmlToParse!.count == 0 {
            return ""
        }
        let  stringVal = stringFromXMLString(xmlToParse:  xmlToParse!)
        return stringVal
        
    }
    
    func stringFromXMLString(xmlToParse:String)->String {
        do
        {
            let xml = SWXMLHash.lazy(xmlToParse)
            let xmlResponse : XMLIndexer? = xml.children.first?.children.first?.children.first
            let xmlResult: XMLIndexer?  = xmlResponse?.children.last
            
            let xmlElement = xmlResult?.element
            _ = xmlElement?.text//修過
            let xmlElementFirst = xmlElement?.children[0] as!TextElement
            return xmlElementFirst.text
        }
        catch
        {
        }
        //NOT IMPLETEMENTED!
        let returnValue: String!
        return returnValue
    }
    
    func stringArrFromXMLString(xmlToParse :String)->[String?]{
        let xml  = SWXMLHash.lazy(xmlToParse)
        let xmlRoot  = xml.children.first
        let xmlBody = xmlRoot?.children.last
        let xmlResponse : XMLIndexer? =  xmlBody?.children.first
        let xmlResult : XMLIndexer?  = xmlResponse?.children.last
        
        var strList = [String?]()
        let childs = xmlResult!.children
        for child in childs {
            let text = child.element?.text
            strList.append(text)
        }
        
        return strList
    }
    
    func stringArrFromXML(data:Data)->[String?]{
        let xmlToParse :String? = String.init(data: data, encoding: String.Encoding.utf8)
        if xmlToParse == nil {
            return [String?]()
        }
        if xmlToParse!.count == 0 {
            return [String?]()
        }
        
        let  stringVal = stringArrFromXMLString(xmlToParse:  xmlToParse!)
        return stringVal
    }
    
    func byteArrayToBase64(bytes: [UInt8]) -> String {
        
        let data = Data.init(_: bytes)//改過 要注意
        let base64Encoded = data.base64EncodedString()
        return base64Encoded;
        
    }
    func base64ToByteArray(base64String: String) -> [UInt8]? {
        if let data = Data.init(base64Encoded: base64String){
            var bytes = [UInt8](repeating: 0, count: data.count)
            data.copyBytes(to: &bytes, count: data.count)
            return bytes;
        }
        return nil // Invalid input
    }
    
    
    
    //Airi-Use
    public func UserLogin(Account: String, Password: String) -> String{
        var soapReqXML: String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"
        
        soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
        soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
        soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
        soapReqXML += " <soap:Body>"
        soapReqXML += "<Sign_in xmlns=\"http://tempuri.org/\">"
        soapReqXML += "<Account>"
        soapReqXML += Account
        soapReqXML += "</Account>"
        soapReqXML += "<Password>"
        soapReqXML += Password
        soapReqXML += "</Password>"
        soapReqXML += "</Sign_in>"
        soapReqXML += "</soap:Body>"
        soapReqXML += "</soap:Envelope>"
        
        let soapAction: String = "http://tempuri.org/Sign_in"
        
        let responseData: Data = SoapHttpClient.callWS(Host: self.Host, WebServiceUrl: self.Url, SoapAction: soapAction, SoapMessage: soapReqXML)
        
        let strVal: String? = stringFromXML(data: responseData);
        if strVal == nil {
            return  ""
        }
        
        let returnValue: String = strVal!
        
        return returnValue
    }
    
    //舊版
    public func UserItem(User: String) -> [String]{
        var soapReqXML: String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"
        
        soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
        soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
        soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
        soapReqXML += " <soap:Body>"
        soapReqXML += "<Select_user xmlns=\"http://tempuri.org/\">"
        soapReqXML += "<Account>"
        soapReqXML += User
        soapReqXML += "</Account>"
        soapReqXML += "</Select_user>"
        soapReqXML += "</soap:Body>"
        soapReqXML += "</soap:Envelope>"
        
        let soapAction: String = "http://tempuri.org/Select_user"
        
        let responseData: Data = SoapHttpClient.callWS(Host: self.Host, WebServiceUrl: self.Url, SoapAction: soapAction, SoapMessage: soapReqXML)
        
        let strVal: [String?] = stringArrFromXML(data: responseData);
        if strVal.isEmpty{
            return  []
        }
        
        let returnValue: [String?] = strVal

        let user: [String: String]
        let sex: String!
        let name: String!
        let local: String!
        let blood: String!
        let mobile: String!
        let address: String!
        let idNumber: String!
        let birthday: String!
        
        
        
        idNumber = returnValue[0]
        name = returnValue[2]
        birthday = returnValue[3]
        blood = returnValue[4]
        sex = returnValue[5]
        local = returnValue[6]
        mobile = returnValue[7]
        address = returnValue[8]
        
        if sex == "G"{
            user = GetUserNewSex(s: "女士")
        }else{
            user = GetUserNewSex(s: "男士")
        }
        
        return [name, user["sex", default: ""], birthday, idNumber, local, mobile, address, blood]
    }
    
    public func UserItem801(User: String) -> [String?]{
        var soapReqXML: String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"
        
        soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
        soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
        soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
        soapReqXML += " <soap:Body>"
        soapReqXML += "<Select_user xmlns=\"http://tempuri.org/\">"
        soapReqXML += "<Account>"
        soapReqXML += User
        soapReqXML += "</Account>"
        soapReqXML += "</Select_user>"
        soapReqXML += "</soap:Body>"
        soapReqXML += "</soap:Envelope>"
        
        let soapAction: String = "http://tempuri.org/Select_user"
        
        let responseData: Data = SoapHttpClient.callWS(Host: self.Host, WebServiceUrl: self.Url, SoapAction: soapAction, SoapMessage: soapReqXML)
        
        let strVal: [String?] = stringArrFromXML(data: responseData);
        if strVal.isEmpty{
            return  []
        }
        
        let returnValue: [String?] = strVal

        var value = [String?]()
        for i in 0...returnValue.count-1{
            if i == 5 {
                if returnValue[i] == "G"{
                    value.append("女士")
                }else{
                    value.append("男士")
                }
            }else{
                value.append(returnValue[i])
            }
        }
        
        return value
    }
        
    //舊版，但跟之前比還是有動過。
    public func UserSign(Account: String, Password: String, Name: String, Birthday: String, Gender: String) -> String{
        let setGender: [String: String]
        if Gender == "女性"{
            setGender = GetUserNewSex(s: "G")
        }else{
            setGender = GetUserNewSex(s: "B")
        }
        var soapReqXML: String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"
        
        soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
        soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
        soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
        soapReqXML += " <soap:Body>"
        soapReqXML += "<User_table xmlns=\"http://tempuri.org/\">"
        soapReqXML += "<Account>"
        soapReqXML += Account
        soapReqXML += "</Account>"
        soapReqXML += "<Password>"
        soapReqXML += Password
        soapReqXML += "</Password>"
        soapReqXML += "<Name>"
        soapReqXML += Name
        soapReqXML += "</Name>"
        soapReqXML += "<Birthday>"
        soapReqXML += Birthday
        soapReqXML += "</Birthday>"
        soapReqXML += "<Gender>"
        soapReqXML += setGender["sex", default: ""]
        soapReqXML += "</Gender>"
        soapReqXML += "</User_table>"
        soapReqXML += "</soap:Body>"
        soapReqXML += "</soap:Envelope>"
        
        let soapAction: String = "http://tempuri.org/User_table"
        
        let responseData: Data = SoapHttpClient.callWS(Host: self.Host, WebServiceUrl: self.Url, SoapAction: soapAction, SoapMessage: soapReqXML)
        
        let strVal: String? = stringFromXML(data: responseData);
        if strVal == nil {
            return  ""
        }
        let returnValue: String = strVal!
        
        return returnValue
    }
    
    public func UserSign801(Account: String, Password: String, Name: String, Birthday: String, Gender: String, ID: String, Blood: String, Local: String, Mobile: String, Address: String) -> String{
        var soapReqXML: String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"
        
        soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
        soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
        soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
        soapReqXML += " <soap:Body>"
        soapReqXML += "<User_table xmlns=\"http://tempuri.org/\">"
        soapReqXML += "<Account>"
        soapReqXML += Account
        soapReqXML += "</Account>"
        soapReqXML += "<Password>"
        soapReqXML += Password
        soapReqXML += "</Password>"
        soapReqXML += "<Name>"
        soapReqXML += Name
        soapReqXML += "</Name>"
        soapReqXML += "<Birthday>"
        soapReqXML += Birthday
        soapReqXML += "</Birthday>"
        soapReqXML += "<Gender>"
        soapReqXML += Gender
        soapReqXML += "</Gender>"
        soapReqXML += "<ID>"
        soapReqXML += ID
        soapReqXML += "</ID>"
        soapReqXML += "<Blood>"
        soapReqXML += Blood
        soapReqXML += "</Blood>"
        soapReqXML += "<Local_call>"
        soapReqXML += Local
        soapReqXML += "</Local_call>"
        soapReqXML += "<Phone_call>"
        soapReqXML += Mobile
        soapReqXML += "</Phone_call>"
        soapReqXML += "<Address>"
        soapReqXML += Address
        soapReqXML += "</Address>"
        soapReqXML += "</User_table>"
        soapReqXML += "</soap:Body>"
        soapReqXML += "</soap:Envelope>"
        
        let soapAction: String = "http://tempuri.org/User_table"
        
        let responseData: Data = SoapHttpClient.callWS(Host: self.Host, WebServiceUrl: self.Url, SoapAction: soapAction, SoapMessage: soapReqXML)
        
        let strVal: String? = stringFromXML(data: responseData);
        if strVal == nil {
            return  ""
        }
        
        let returnValue: String = strVal!
        
        return returnValue
    }
    
    //舊版
    public func UpdateUser(Account: String, ID: String, Blood: String, Local: String, Phone: String, Address: String, Profession: String) -> String{
        var soapReqXML: String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"
        
        soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
        soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
        soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
        soapReqXML += " <soap:Body>"
        soapReqXML += "<User_updata xmlns=\"http://tempuri.org/\">"
        soapReqXML += "<Account>"
        soapReqXML += Account
        soapReqXML += "</Account>"
        soapReqXML += "<ID>"
        soapReqXML += ID
        soapReqXML += "</ID>"
        soapReqXML += "<Blood>"
        soapReqXML += Blood
        soapReqXML += "</Blood>"
        soapReqXML += "<Local_call>"
        soapReqXML += Local
        soapReqXML += "</Local_call>"
        soapReqXML += "<Phone_call>"
        soapReqXML += Phone
        soapReqXML += "</Phone_call>"
        soapReqXML += "<Address>"
        soapReqXML += Address
        soapReqXML += "</Address>"
        soapReqXML += "<Profession>"
        soapReqXML += Profession
        soapReqXML += "</Profession>"
        soapReqXML += "</User_updata>"
        soapReqXML += "</soap:Body>"
        soapReqXML += "</soap:Envelope>"
        
        let soapAction: String = "http://tempuri.org/User_updata"
        
        let responseData: Data = SoapHttpClient.callWS(Host: self.Host, WebServiceUrl: self.Url, SoapAction: soapAction, SoapMessage: soapReqXML)
        
        let strVal: String? = stringFromXML(data: responseData);
        if strVal == nil {
            
            return  ""
        }
        let returnValue: String = strVal!
        
        return returnValue
    }
    
    public func UpdateUser801(Account: String, Blood: String, Local: String, Phone: String, Address: String, Profession: String) -> String{
        var soapReqXML: String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"
        
        soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
        soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
        soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
        soapReqXML += " <soap:Body>"
        soapReqXML += "<User_Change xmlns=\"http://tempuri.org/\">"
        soapReqXML += "<Account>"
        soapReqXML += Account
        soapReqXML += "</Account>"
        soapReqXML += "<Blood>"
        soapReqXML += Blood
        soapReqXML += "</Blood>"
        soapReqXML += "<Local_call>"
        soapReqXML += Local
        soapReqXML += "</Local_call>"
        soapReqXML += "<Phone_call>"
        soapReqXML += Phone
        soapReqXML += "</Phone_call>"
        soapReqXML += "<Address>"
        soapReqXML += Address
        soapReqXML += "</Address>"
        soapReqXML += "<Profession>"
        soapReqXML += Profession
        soapReqXML += "</Profession>"
        soapReqXML += "</User_Change>"
        soapReqXML += "</soap:Body>"
        soapReqXML += "</soap:Envelope>"
        
        let soapAction: String = "http://tempuri.org/User_Change"
        
        let responseData: Data = SoapHttpClient.callWS(Host: self.Host, WebServiceUrl: self.Url, SoapAction: soapAction, SoapMessage: soapReqXML)
        
        let strVal: String? = stringFromXML(data: responseData);
        if strVal == nil {            
            return  ""
        }
        let returnValue: String = strVal!
        
        return returnValue
    }
    
    //2023 OK
    public func AddPhysiological(Account: String, CheckSample: String, CheckDate: String, CheckTime: String, CheckData: String) -> String{
        var soapReqXML: String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"
        
        soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
        soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
        soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
        soapReqXML += " <soap:Body>"
        soapReqXML += "<Physiological_table xmlns=\"http://tempuri.org/\">"
        soapReqXML += "<Account>"
        soapReqXML += Account
        soapReqXML += "</Account>"
        soapReqXML += "<Check_Sample>"
        soapReqXML += CheckSample
        soapReqXML += "</Check_Sample>"
        soapReqXML += "<Check_Date>"
        soapReqXML += CheckDate
        soapReqXML += "</Check_Date>"
        soapReqXML += "<Check_Time>"
        soapReqXML += CheckTime
        soapReqXML += "</Check_Time>"
        soapReqXML += "<Check_Data>"
        soapReqXML += CheckData
        soapReqXML += "</Check_Data>"
        soapReqXML += "</Physiological_table>"
        soapReqXML += "</soap:Body>"
        soapReqXML += "</soap:Envelope>"
        
        let soapAction: String = "http://tempuri.org/Physiological_table"
        
        let responseData: Data = SoapHttpClient.callWS(Host: self.Host, WebServiceUrl: self.Url, SoapAction: soapAction, SoapMessage: soapReqXML)
        
        let strVal: String? = stringFromXML(data: responseData);
        if strVal == nil {
            return  ""
        }
        let returnValue: String = strVal!
        
        return returnValue
    }
    
    //OK SelectNewHistory
    public func SelectTable(TableName: String, User: String, Sample: String) -> [String]{
        var soapReqXML: String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"
        
        soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
        soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
        soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
        soapReqXML += " <soap:Body>"
        soapReqXML += "<Select xmlns=\"http://tempuri.org/\">"
        soapReqXML += "<table_name>"
        soapReqXML += TableName
        soapReqXML += "</table_name>"
        soapReqXML += "<Account>"
        soapReqXML += User
        soapReqXML += "</Account>"
        soapReqXML += "<Sample>"
        soapReqXML += Sample
        soapReqXML += "</Sample>"
        soapReqXML += "</Select>"
        soapReqXML += "</soap:Body>"
        soapReqXML += "</soap:Envelope>"
        
        let soapAction: String = "http://tempuri.org/Select"
        
        let responseData: Data = SoapHttpClient.callWS(Host: self.Host, WebServiceUrl: self.Url, SoapAction: soapAction, SoapMessage: soapReqXML)
        let strVal: [String?] = stringArrFromXML(data: responseData);
        if strVal.isEmpty {
                    return  []
                }
        let returnValue: [String?] = strVal

        let value: String!
        let date: String!
        value = returnValue[0]
        date = returnValue[1]
        
        return [value, date]
    }
    
    public func StringToCGFloat(data: String?)->(CGFloat){
        let nsdata = data
        var data: CGFloat = 0
        
        if let doubleValue = Double(nsdata!){
            data  = CGFloat(doubleValue)
        }
        return data
    }
    
    //舊版
    public func SelectAllPhy(User: String, Sample: String) -> [String?]{
        var soapReqXML: String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"
        
        soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
        soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
        soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
        soapReqXML += " <soap:Body>"
        soapReqXML += "<Select xmlns=\"http://tempuri.org/\">"
        soapReqXML += "<table_name>"
        soapReqXML += "Health_Record_Table"//
        soapReqXML += "</table_name>"
        soapReqXML += "<Account>"
        soapReqXML += User
        soapReqXML += "</Account>"
        soapReqXML += "<Sample>"
        soapReqXML += Sample
        soapReqXML += "</Sample>"
        soapReqXML += "</Select>"
        soapReqXML += "</soap:Body>"
        soapReqXML += "</soap:Envelope>"
        
        let soapAction: String = "http://tempuri.org/Select"
        
        let responseData: Data = SoapHttpClient.callWS(Host: self.Host, WebServiceUrl: self.Url, SoapAction: soapAction, SoapMessage: soapReqXML)
        let strVal: [String?] = stringArrFromXML(data: responseData);
        if strVal.isEmpty {
            return  []
        }
        let returnValue: [String?] = strVal

        var value = [String?]()
        
        for i in 0...returnValue.count-1{
            value.append(returnValue[i])//
        }
        
        return value
    }
    
    public func SelectAllPhy801(User: String, Sample: String) -> [CGFloat?]{
        var soapReqXML: String = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"
        
        soapReqXML  += "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""
        soapReqXML  += " xmlns:xsd =\"http://www.w3.org/2001/XMLSchema\""
        soapReqXML  += " xmlns:soap =\"http://schemas.xmlsoap.org/soap/envelope/\">"
        soapReqXML += " <soap:Body>"
        soapReqXML += "<Select xmlns=\"http://tempuri.org/\">"
        soapReqXML += "<table_name>"
        soapReqXML += "Health_Record_Table"
        soapReqXML += "</table_name>"
        soapReqXML += "<Account>"
        soapReqXML += User
        soapReqXML += "</Account>"
        soapReqXML += "<Sample>"
        soapReqXML += Sample
        soapReqXML += "</Sample>"
        soapReqXML += "</Select>"
        soapReqXML += "</soap:Body>"
        soapReqXML += "</soap:Envelope>"
        
        let soapAction: String = "http://tempuri.org/Select"
        
        let responseData: Data = SoapHttpClient.callWS(Host: self.Host, WebServiceUrl: self.Url, SoapAction: soapAction, SoapMessage: soapReqXML)
        let strVal: [String?] = stringArrFromXML(data: responseData);
        if strVal.isEmpty {
            return  []
        }
        let returnValue: [String?] = strVal

        var value = [CGFloat?]()
        
        for i in 0...returnValue.count-1{
            value.append(StringToCGFloat(data: returnValue[i]))
        }
        
        return value
    }
}

func GetUserNewSex(s: String) -> [String: String] {
    ["sex": s]
}
