//
//  ArrayOfInt.swift
//  UseMed2
//
//  Created by rm on 2022/11/5.
//

import Foundation
public class ArrayOfInt{
     public var intArr : [Int] = []
}
