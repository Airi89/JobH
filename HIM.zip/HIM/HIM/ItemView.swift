//
//  Person.swift
//  ItemView.swift
//  HIM
//
//  Created by MILab on 2022/10/3.
//

import SwiftUI
import SwiftUICharts

struct Bar: Identifiable{
    var id: Int
    var bpm: [String]
    var value: [Int]
    var color: [Color]
}

struct ItemView: View {
    var User: String
    @State var ItemIndex = 0
    var ItemName = ["血壓", "血脂", "飯前血糖", "飯後血糖", "心跳"]
    var body: some View {
        let hr = MItemHR(account: User).map{($0.phyBpm)}
        let hrValue = MItemHR(account: User).map{($0.phyValue)}
        let hrColor = MItemHR(account: User).map{($0.phyColor)}
        TabView(selection: $ItemIndex){
            let phyHistory = ItemDetail(account: User, item: ItemEnglish(item: ItemIndex)).map{($0.phyValue)}
            VStack {
                switch ItemIndex{
                case 0:
                    let dbpHistory = ItemDetail(account: User, item: "DBP").map{($0.phyValue)}
                    ScrollView{
                        MultiLineChartView(data: [(phyHistory, GradientColors.green), (dbpHistory, GradientColors.purple)], title: "血壓總表", form: ChartForm.extraLarge)
                        HStack{
                            LineChartView(data: phyHistory, title: "收縮壓", legend: "", valueSpecifier: "%.0f")
                            LineChartView(data: dbpHistory, title: "舒張壓", legend: "", valueSpecifier: "%.0f")
                        }
                        ItemIndexLabel(txtIndex: 0)
                    }
                case 3://AC&PC
                    LineView(data: phyHistory, title: "", legend: "", legendSpecifier: "%.0f")
                        .padding(3)
                    ItemIndexLabel(txtIndex: 2)
                case 4://HR
                    var myBar = Bar(id: 1, bpm: hr, value: hrValue, color: hrColor)
                    itemView(vbar: myBar)
                    ItemIndexLabel(txtIndex: 3)
                default:
                    LineView(data: phyHistory, title: "", legend: "", legendSpecifier: "%.0f")
                        .padding(3)
                    ItemIndexLabel(txtIndex: ItemIndex)
                }
            }.tag(0)
        }.navigationTitle(ItemName[ItemIndex])
    }
}

struct Person_Previews: PreviewProvider {
    static var previews: some View {
        ItemView(User: "")
    }
}

//OK
struct itemView: View{
    var vbar: Bar
    var body: some View{
        HStack(alignment: .bottom){
            ForEach(vbar.value.indices, id: \.self){ index in
                VStack{
                    ZStack{
                        Rectangle()
                            .foregroundColor(vbar.color[index])
                            .frame(width: 40, height: CGFloat(vbar.value[index]) + 40, alignment: .bottom)
                            .cornerRadius(6)
//                            .opacity(seID == bar.id ? 0.5 : 1.0)
//                            .onTapGesture {
//                                self.seID = bar.id
//                            }
                        Text("\(vbar.value[index])")
                            .font(.system(size: 22))
                            .foregroundColor(.white)
                    }

                    Text(vbar.bpm[index])
                }
            }
        }.frame(height: 300, alignment: .bottom)
            .background(.thinMaterial)
            .cornerRadius(6)
    }
}

//OK
struct ItemIndexLabel: View {
    var txtIndex: Int
    var ItemIntroduce = ["血壓是血液流動時對動脈管壁造成的壓力，心臟打出血液打到動脈時的壓力，就產生收縮壓，心臟舒張時，血液回流的壓力，則是舒張壓。這兩者分別代表了血管在心臟舒張和收縮時，所承受的壓力。壓力大小的變化造就了高血壓和低血壓。", "人體膽固醇有兩大來源，一是身體會自然生成所需的膽固醇，70～80%由肝臟生成，另外則是從食物中攝取，大多動物性食品包括：蛋黃、肉類或起司等，都含有膽固醇。\n如果血液中膽固醇含量過高，會容易堆積動脈斑塊，這種情形就稱為動脈粥狀硬化，會導致造成血管狹窄、阻塞，進而導致冠狀動脈疾病等心血管疾病。", "血液中的葡萄糖被稱為血糖，血液將葡萄糖帶到人體所有細胞中，提供人體所需能量。不過葡萄糖需要胰島素的幫助才能有效提供細胞能量，而當我們體內胰島素缺乏或功能不全，就會造成血糖過高，進一步造成糖尿病等其他嚴重問題。", "在臨床上，心跳過快通常是因為心臟的心房或心室有問題。心房異常以心房顫動最為常見，而心室異常則以陣發性心室上心搏過速最常見，心室頻脈最為致命。"]
    var body: some View {
        VStack{
            TextStyle(txtStyle: ItemIntroduce[txtIndex], txtColor: .brown, txtFSize: 20)
                .background(Color(.systemGray6))
                .cornerRadius(20)
        }.padding(10)
    }
}

//MoOK
struct Stock{
    let phyValue: Double
}
private func ItemDetail(account: String, item: String) -> [Stock]{
    let myweb = AiriWS()
    let res = myweb.SelectAllPhy801(User: account, Sample: item)//
    
    var stocks = [Stock]()
    if !res.isEmpty{
        for i in 0...res.count-1{
            let stock = Stock(phyValue: res[i] ?? 0)
            if stock.phyValue != 0{
                stocks.append(stock)
            }
        }
    }
    return stocks
}

//MoOK
struct HRStocktes{
    let phyValue: Int
    let phyBpm: String
    let phyColor: Color
}
private func MItemHR(account: String) -> [HRStocktes]{
    let myweb = AiriWS()
    let res = myweb.SelectAllPhy801(User: account, Sample: "HR")//
    let bpms = ["60以下", "61-70", "71-80", "81-90", "91-100", "101以上"]
    let colors = [Color.orange, Color.yellow, Color.green, Color.green, Color.gray, Color.gray]
    
    var sum = [0, 0, 0, 0, 0, 0]
    
    var stocks = [HRStocktes]()
    var stocksDetail = [HRStocktes]()
    if !res.isEmpty{
        for i in 0...res.count-1{
            let stock = HRStocktes(phyValue: Int(res[i] ?? 0), phyBpm: bpms[0], phyColor: .primary)
            if stock.phyValue != 0{
                if stock.phyValue > 100{
                    sum[5] += 1
                }else if stock.phyValue > 90{
                    sum[4] += 1
                }else if stock.phyValue > 80{
                    sum[3] += 1
                }else if stock.phyValue > 70{
                    sum[2] += 1
                }else if stock.phyValue > 60{
                    sum[1] += 1
                }else{
                    sum[0] += 1
                }
            }
            
            //Self.View
            let stockDetail = HRStocktes(phyValue: Int(res[i] ?? 0), phyBpm: bpms[0], phyColor: .primary)
            if stockDetail.phyValue != 0{
                stocksDetail.append(stockDetail)
            }
        }
        
        for j in 0...bpms.count-1{
            if sum[j] != 0{
                let Realstock = HRStocktes(phyValue: sum[j], phyBpm: bpms[j], phyColor: colors[j])
                stocks.append(Realstock)
            }
        }
    }
    return stocks
}

//OK
private func ItemEnglish(item: Int) -> String{
    var value: Int
    let ItemName = ["SBP", "TC", "AC", "PC", "SpO2", "HR"]
    
    value = item
    
    return ItemName[value]
}


