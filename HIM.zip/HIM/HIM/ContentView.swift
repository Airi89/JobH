//
//  ContentView.swift
//  HIM
//
//  Created by MILab on 2022/9/27.
//

import SwiftUI
import LocalAuthentication


struct ContentView: View {
    let myweb = AiriWS()
    @State var account = ""
    @State var password = ""
    @State var NoAccount = false
    @State var NoPassword = false
    @State var navLinkActive = false//
    @State var faceLinkActive = false//
    @State private var showSign = false
    @State private var isUnLocked = false
    var body: some View {
        NavigationView {
            VStack(spacing: 30){
                VStack{
                    Image("Logo")
                        .resizable()
                        .scaledToFit()
                }.padding(.top, 15)
                Spacer()
                
                VStack{
                    HStack{
                        FormTextField(label: "帳號：",placeholder: "請輸入帳號", value: $account)
                    }.padding(.horizontal, 35)
                    if NoAccount{
                        Text("查無帳號，請按下方註冊！")
                            .foregroundColor(.pink)
                    }
                    
                    HStack{
                        Text("密碼：")
                            .font(.system(size:28, design: .rounded))
                        FormSecureField(passwordText: "請輸入密碼", label: $password)
                    }.padding(.horizontal, 35)
                    if NoPassword{
                        Text("密碼錯誤，請重新輸入！")
                            .foregroundColor(.pink)
                    }
                    Spacer()
                }
                
                VStack{
                    Button{
                        let res = myweb.UserLogin(Account: account, Password: password)
                        if res == "0"{
                            isUnLocked = false
                            navLinkActive = true
                            NoAccount = false
                            NoPassword = false
                        }else if res == "No this Account"{
                            NoAccount = true
                        }else{
                            NoPassword = true
                        }
                    }label: {
                        BtnStyle(label: "登入", btnColor: Color("AccentColor"), foreColor: .white)
                    }.disabled(account.isEmpty || password.isEmpty)
                    
                    Button(action:{
                        showSign = true
                    }){
                        BtnStyle(label: "註冊", btnColor: Color(.systemGray4), foreColor: .white)
                            .sheet(isPresented: $showSign){SignView()}//
                    }
                }
                if isUnLocked{
                    NavigationLink(destination: LogView(user: "08400801"),isActive: $faceLinkActive){
                    }
                }else{
                    NavigationLink(destination: LogView(user: account),isActive: $navLinkActive){
                    }
                }
            }.navigationBarTitleDisplayMode(.inline)
        }.onAppear(perform: BiometricsLogin)
    }
    func BiometricsLogin() {
        // 生物辨識物件
        let context = LAContext()
        var error: NSError?
        /* LAPolicy tpye : Int
         
         只支援 FaceID 跟 指紋辨識 驗證
         deviceOwnerAuthenticationWithBiometrics = 1
         
         支援 FaceID, 指紋辨識, 裝置密碼 驗證
         deviceOwnerAuthentication = 2
         */
        
        // 判斷是否可以用 FaceID, 指紋辨識, 裝置密碼登入 -> Bool
        if context.canEvaluatePolicy(.deviceOwnerAuthentication, error: &error) {
            // 當 FaceID 或 指紋辨識 第一次驗證失敗，彈跳系統制式alert，alert上的取消button文字描述
            context.localizedCancelTitle = "取消登入"
            // localizedFallbackTitle 是在多次驗證失敗後，會出現在系統制式alert上的button文字描述
            context.localizedFallbackTitle = "使用輸入帳密方式登入"
            // 當 FaceID 或 指紋辨識 驗證失敗多次，彈跳系統制式alert，alert上的說明描述
            
            //            let reason = "選用輸入帳密方式登入或是取消登入"
            let reason = "使用Face ID解鎖"
            
            // 使用 FaceID, 指紋辨識, 裝置密碼登入驗證
            context.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: reason) { (result, err) in
                if result {
                    isUnLocked = true
                    faceLinkActive = true
                } else {
                    // 驗證失敗
                    guard let nsError = err as NSError? else { return }
                    let errorCode = Int32(nsError.code)
                    switch errorCode {
                    case kLAErrorAuthenticationFailed: print("驗證資訊出錯")
                    case kLAErrorUserCancel: print("使用者取消驗證")
                    case kLAErrorUserFallback: print("使用者選擇其他驗證方式")
                    case kLAErrorSystemCancel: print("被系統取消")
                    case kLAErrorPasscodeNotSet: print("iPhone沒設定密碼")
                    case kLAErrorTouchIDNotAvailable: print("使用者裝置不支援Touch ID")
                    case kLAErrorTouchIDNotEnrolled: print("使用者沒有設定Touch ID")
                    case kLAErrorTouchIDLockout: print("功能被鎖定(五次)，下一次需要輸入手機密碼")
                    case kLAErrorAppCancel: print("在驗證中被其他app終止")
                    default: print("驗證失敗")
                    }
                }
            }
        } else {
            print(error?.localizedDescription ?? "用戶拒絕使用")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
//        addMenu(User: "08400801")
    }
}

struct LogView: View {
    let user: String
    let myweb = AiriWS()
    @State private var LogOut = false
    @State private var phyMenu = false
    @State private var showOptions = false
    
    @Environment(\.dismiss) var dismiss
    
    var tableName = "Health_Record_Table"
    var phyTitle = ["血氧", "血壓", "心跳"]
    var phyUnit = ["%", "mmHg", "bpm"]
    
    var body: some View {
        let res = UserItem(item: user).map{($0.UserValue)}
        let PhyNew = PhyItem(account: user).map{($0.phyValue)}
        VStack{
            LogoStyle(MyW: 200, MyH: 200)
            VStack{
                HStack{
                    VStack(alignment: .leading){
                        Text("\(res[2]) \(res[5])")
                            .font(.system(size: 28))
                        //                            .foregroundColor(Color("AccentColor"))
                            .padding(.leading, 25)
                        DateTimeString()
                            .padding(.leading, 25)
                    }
                    Spacer()
                    VStack(alignment: .leading){
                        ForEach(phyTitle.indices, id: \.self){ index in
                            if PhyNew[index] == "無資料"{
                                Text("\(phyTitle[index])：無資料")
                            }else{
                                switch index{
                                case 0:
                                    Text("\(phyTitle[index])：\(PhyNew[index]) \(phyUnit[index])")
                                case 2:
                                    Text("\(phyTitle[index])：\(PhyNew[3]) \(phyUnit[index])")
                                default:
                                    Text("\(phyTitle[index])：\(PhyNew[1])／\(PhyNew[2]) \(phyUnit[index])")
                                }
                            }
                        }                        
                    }.font(.system(size: 20))
                    Spacer()
                }
                Divider().background(Color.brown)
                
                NavigationLink(destination: MainView(TabIndex: 0, User: user)){
                    HStack{
                        ImageStyle(imgStyle: "Physiological")
                        TextStyle(txtStyle: "生理數據查詢", txtColor: .brown, txtFSize: 30)
                    }
                }.padding(10)
                Divider().background(Color.brown)
                
                NavigationLink(destination: MainView(TabIndex: 1, User: user)){
                    HStack{
                        ImageStyle(imgStyle: "HomeSafe")
                        TextStyle(txtStyle: "居家安全查詢", txtColor: .brown, txtFSize: 30)
                    }
                }.padding(10)
                Divider().background(Color.brown)
                
                NavigationLink(destination: MainView(TabIndex: 2, User: user)){
                    HStack{
                        ImageStyle(imgStyle: "Weather")
                        TextStyle(txtStyle: "空氣品質查詢", txtColor: .brown, txtFSize: 30)
                    }
                }.padding(10)
            }
            Spacer()
        }.navigationBarTitle("首頁")
            .navigationBarItems(trailing:Label("",systemImage: "gear.circle")
                .font(.system(size: 24))
                .foregroundColor(Color("AccentColor"))
                .onTapGesture{showOptions.toggle()}
                .actionSheet(isPresented: $showOptions){
                    ActionSheet(title: Text("設定"),
                                message:nil,
                                buttons: [
                                    .default(Text("新增生理資訊")){phyMenu.toggle()},
                                    .default(Text("登出")){self.LogOut.toggle()},
                                    .cancel(Text("取消"))])
                })//請檢查個人資料，修改後傳值問題
        
        //, local: res[6], mobile: res[7], address: res[8], picblood: res[4]
            .navigationBarItems(trailing:NavigationLink(destination: PersonView(User: user, work: res[9], local: res[6], mobile: res[7], address: res[8], picblood: res[4])){Label("",systemImage: "person")}
                .font(.system(size: 24)))
            .navigationBarBackButtonHidden()
            .alert(isPresented: $LogOut){
                Alert(title: Text("登出"),message: Text("請問您是否要登出"),
                      primaryButton: .default(Text("確定"), action: {dismiss()}),
                      secondaryButton: .cancel(Text("取消")))
            }
            .sheet(isPresented: $phyMenu){
                addMenu(User: user)
            }
    }
}
struct UserStock{
    let UserValue: String
}

private func UserItem(item: String) -> [UserStock]{
    let myweb = AiriWS()
    let res = myweb.UserItem801(User: item)
    
    var value: String!
    var stocks = [UserStock]()
    for i in 0...res.count-1{
        value = res[i]
        let stock = UserStock(UserValue: value)
        stocks.append(stock)
    }
    return stocks
}
struct ThreeStocktes{
    let phyValue: String//
}
private func PhyItem(account: String) -> [ThreeStocktes]{
    let myweb = AiriWS()
    let itemValue = [
        myweb.SelectTable(TableName: "Health_Record_Table", User: account, Sample: "SpO2"),
        myweb.SelectTable(TableName: "Health_Record_Table", User: account, Sample: "SBP"),
        myweb.SelectTable(TableName: "Health_Record_Table", User: account, Sample: "DBP"),
        myweb.SelectTable(TableName: "Health_Record_Table", User: account, Sample: "HR")
    ]
    
    var value: String!
    var stocks = [ThreeStocktes]()
    
    for i in 0...itemValue.count-1{
        let returnValue = itemValue[i]
        if returnValue.isEmpty{
            value = "無資料"
        }else{
            value = returnValue[0]//
        }
        let stock = ThreeStocktes(phyValue: value)
        stocks.append(stock)
    }
    return stocks
}

struct addMenu: View{
    let User: String
    let myweb = AiriWS()
    @State private var Data = ""
    @State private var dbpData = ""
    @State private var roleIndex = 0
    @State private var checkD = Date()
    @State private var checkT = Date()    
    @Environment(\.dismiss) var dismiss
    
    struct Role {
        let Item: String
        let EngItem: String
    }
    let roles = [
        Role(Item: "血壓", EngItem: "SBP"),//DBP
        Role(Item: "血脂", EngItem: "TC"),
        Role(Item: "飯前血糖", EngItem: "AC"),
        Role(Item: "飯後血糖", EngItem: "PC"),
        Role(Item: "血氧", EngItem: "SpO2"),
        Role(Item: "心跳", EngItem: "HR")
    ]
    
    let Items = ["日期", "時間", "測量值"]
    let Unit = ["mg/dL", "mg/dL", "mg/dL", "%", "bpm"]
    let photos = ["SBP", "TC", "AC", "PC", "SpO2", "HR"]
    var body: some View{
        NavigationView{
            VStack{         
                List{
                    VStack{
                        Picker(selection: $roleIndex) {
                            ForEach(roles.indices, id: \.self){ item in
                                Text(roles[item].Item)
                                    .font(.system(size: 32))
                            }
                        } label: {
                        }
                        .pickerStyle(.wheel)
                        .frame(height: 90)
                        .background(Color(.systemGray6))
                        .cornerRadius(35)
                        .shadow(radius: 8)
                    }
                    HStack{
                        Text(Items[0]).font(.title2)
                        Spacer()
                        DatePicker("", selection: $checkD, in: ...Date(), displayedComponents: .date)
                            .labelsHidden()
                            .environment(\.locale, Locale(identifier: "zh_Hant_TW"))
                        Spacer()
                    }.padding(6)
                    HStack{
                        Text(Items[1]).font(.title2)
                        Spacer()
                        DatePicker("", selection: $checkT, displayedComponents: .hourAndMinute)
                            .labelsHidden()
                            .environment(\.locale, Locale(identifier: "zh_Hant_TW"))
                        Spacer()
                    }.padding(6)
                    
                    VStack{
                        VStack{
                            if roles[roleIndex].Item == "血壓"{
                                AddLabelField(placeholder: "收縮壓(mmHg)", value: $Data)
                                AddLabelField(placeholder: "舒張壓(mmHg)", value: $dbpData)
                            }else{
                                AddLabelField(placeholder: "測量值(\(Unit[roleIndex-1]))", value: $Data)
                            }
                        }
                    }
                    
                    VStack{
                        if Data.isEmpty{
                            Text("請輸入數值")
                                .font(.system(size: 24))
                                .foregroundColor(.pink)
                        }
                        HStack{
                            Image(roles[roleIndex].EngItem)//
                                .resizable()
                                .scaledToFit()
                        }
                    }
                }
            }
            .navigationTitle("新增生理數據")
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: {
                        dismiss()
                    }){
                        Text("取消").foregroundColor(.red)
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: {
                        let datestr = myweb.dateToString(date: checkD)
                        let timestr = myweb.timeToString(date: checkT)
                        if !Data.isEmpty{
                            if roles[roleIndex].Item == "血壓"{
                                if !dbpData.isEmpty{
                                    let a = Int(Data) ?? 0
                                    let b = Int(dbpData) ?? 0
                                    if a > 300 || a < 90{
                                        Data = ""
                                        return
                                    }
                                    if b > 150 || b < 60{
                                        dbpData = ""
                                        return
                                    }
                                    let res = myweb.AddPhysiological(Account: User, CheckSample: "SBP", CheckDate: datestr, CheckTime: timestr, CheckData: Data)
                                    let resDBP = myweb.AddPhysiological(Account: User, CheckSample: "DBP", CheckDate: datestr, CheckTime: timestr, CheckData: dbpData)
                                    if res == "Insert_OK" && resDBP == "Insert_OK" {
                                        dismiss()
                                    }
                                }
                            }else{
                                let c = Int(Data) ?? 0
                                if roles[roleIndex].Item == "血脂"{
                                    if c > 300 || c < 30{
                                        Data = ""
                                        return
                                    }
                                }
                                if roles[roleIndex].Item == "飯前血糖"{
                                    if c > 180 || c < 45{
                                        Data = ""
                                        return
                                    }
                                }
                                if roles[roleIndex].Item == "飯後血糖"{
                                    if c > 300 || c < 65{
                                        Data = ""
                                        return
                                    }
                                }
                                if roles[roleIndex].Item == "血氧"{
                                    if c > 100 || c < 95{
                                        Data = ""
                                        return
                                    }
                                }
                                if roles[roleIndex].Item == "心跳"{
                                    if c > 260 || c < 45{
                                        Data = ""
                                        return
                                    }
                                }
                                let res = myweb.AddPhysiological(Account: User, CheckSample: roles[roleIndex].EngItem, CheckDate: datestr, CheckTime: timestr, CheckData: Data)
                                if res == "Insert_OK"{
                                    dismiss()
                                }
                            }
                        }
                    }) {
                        Text("新增")
                            .font(.headline)
                            .foregroundColor(.cyan)
                    }
                }
            }
        }
    }
}


//登入、主頁、註冊介面
struct LogoStyle: View {
    let MyW: CGFloat
    let MyH: CGFloat
    var body: some View {
        Image("Logo")
            .resizable()
            .frame(width: MyW, height: MyH)
            .scaledToFit()
    }
}

//登入介面—兩個按鈕使用
struct BtnStyle: View {
    let label: String
    let btnColor: Color
    let foreColor: Color
    var body: some View {
        Text(label)
            .padding(10)
            .frame(width: 155)
            .font(.system(size:28))
            .foregroundColor(foreColor)
            .background(btnColor)
            .cornerRadius(32)
    }
}

//主頁介面—三個圓圈使用
struct ImageStyle: View{
    let imgStyle: String
    var body: some View{
        Image(imgStyle)
            .resizable()
            .scaledToFit()
            .frame(width: 105)
            .background(Color("AccentColor"))
            .cornerRadius(50)
    }
}

//主頁介面—三個圓圈旁文字說明使用；生理數據細項介紹
struct TextStyle: View{
    let txtStyle: String
    let txtColor: Color
    let txtFSize: CGFloat
    var body: some View{
        Text(txtStyle)
            .padding(18)
            .font(.system(size:txtFSize))
            .foregroundColor(txtColor)
    }
}

//登入介面—帳號文字方塊
struct FormTextField: View{
    let label: String
    var placeholder: String = ""
    @Binding var value: String
    
    var body: some View{
        VStack{
            HStack{
                Text(label.uppercased())
                    .font(.system(size:28, design: .rounded))
                //  .font(.custom("NotoSerifTC-Bold", size: 30))
                TextField(placeholder, text: $value)
                    .font(.system(size:30,design: .rounded))
                    .textFieldStyle(PlainTextFieldStyle())
                    .padding(10)
                    .overlay(RoundedRectangle(cornerRadius: 15)
                        .stroke(Color(.systemGray5),lineWidth: 2.5))
            }
        }.padding(.vertical,10)
    }
}

//登入、註冊—密碼遮罩
struct FormSecureField: View{
    let passwordText: String
    @Binding var label: String
    
    var body: some View{
        VStack{
            SecureField(label, text: $label, prompt: Text(passwordText))
                .font(.system(size: 30, design: .rounded))
                .textFieldStyle(PlainTextFieldStyle())
                .padding(10)
                .overlay(RoundedRectangle(cornerRadius: 15)
                    .stroke(Color(.systemGray5), lineWidth: 2.5))
        }.padding(.vertical, 10)
    }
}

//個人資料介面—細項個資文字方塊
struct FormLabelField: View{
    let label: String
    var placeholder: String = ""
    @Binding var value: String
    
    var body: some View{
        VStack{
            Text(label.uppercased())
                .font(.system(size: 32))
                .fontWeight(.bold)
            TextField(placeholder, text: $value)
                .font(.system(size:30, design: .rounded))
                .textFieldStyle(PlainTextFieldStyle())
                .padding(8)
                .overlay(RoundedRectangle(cornerRadius: 15)
                    .stroke(Color(.systemGray5), lineWidth: 2.5))
        }.padding(10)
    }
}

//新增資料介面—測量值
struct AddLabelField: View{
    var placeholder: String = ""
    @Binding var value: String
    
    var body: some View{
        VStack{
            TextField(placeholder, text: $value)
                .font(.system(size:30, design: .rounded))
                .textFieldStyle(PlainTextFieldStyle())
                .padding(10)
                .overlay(RoundedRectangle(cornerRadius: 15)
                    .stroke(Color(.systemGray5), lineWidth: 2.5))
                .keyboardType(.numberPad)
        }.padding(10)
    }
}
