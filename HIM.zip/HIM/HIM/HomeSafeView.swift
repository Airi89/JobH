//
//  HomeSafeView.swift
//  HIM
//
//  Created by MILab on 2022/11/16.
//

import SwiftUI

var number = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"]
var dateTest = ["02/23", "03/02"]

struct HomeSafeView: View {
    
    
    
    var body: some View {
        VStack{
            Text("近一年的歷史資料")
            MonthString()
            dateString()
            List{
                ForEach(dateTest.indices, id: \.self){ index in
                    ZStack {
                        HStack{
//                            Text("第\(number[index])筆")                                
                            Text("\(dateTest[index])")
                                .padding(18)
                            Spacer()
                            Text("異常")
                                .foregroundColor(.pink)
                        }.font(.system(size: 24))
                    }
                }
            }
        }
    }
}

struct HomeSafeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeSafeView()
    }
}

struct MonthString: View {
    @State private var HistroyDate = Date()
    
    let NowMonth = Date()
    static let sMonthFormat: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "MM"
        return formatter
    }()
    
    var body: some View {
        HStack{
            DatePicker("", selection: $HistroyDate, displayedComponents: .date)
                .labelsHidden()
                .environment(\.locale, Locale(identifier: "zh_Hant_TW"))
                .environment(\.calendar, Calendar(identifier: .republicOfChina))
            //            Text(HistroyDate.formatted(.dateTime.month()))
            //            Text("\(NowMonth, formatter: Self.sMonthFormat)")
            
            //            if(HistroyDate.formatted(.dateTime.month()) == sMonthFormat){
            //
            //            }
        }
    }
}

struct dateString: View {
    @State private var HistroyDate = Date()
    
    let NowMonth = Date()
    static let sDateFormat: DateFormatter = {
        let formatter = DateFormatter()
//        formatter.dateFormat = "yyyy/MM/dd"
        formatter.dateFormat = "yyyy/MM/dd  HH:mm:ss"
        return formatter
    }()
    
    var body: some View {
        HStack{
            Text("\(NowMonth, formatter: Self.sDateFormat)")
//            DatePicker("", selection: $HistroyDate, displayedComponents: .date)
//                .labelsHidden()
//                .environment(\.locale, Locale(identifier: "zh_Hant_TW"))
//                .environment(\.calendar, Calendar(identifier: .republicOfChina))
            //            Text(HistroyDate.formatted(.dateTime.month()))
            //            Text("\(NowMonth, formatter: Self.sMonthFormat)")
            
            //            if(HistroyDate.formatted(.dateTime.month()) == sMonthFormat){
            //
            //            }
        }
    }
}
