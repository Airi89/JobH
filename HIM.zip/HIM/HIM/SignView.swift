//
//  SignView.swift
//  HIM
//
//  Created by MILab on 2022/10/8.
//

import SwiftUI
import CodeScanner


struct SignView: View {
    init(){
        UIPageControl.appearance().currentPageIndicatorTintColor = .systemBlue
        UIPageControl.appearance().pageIndicatorTintColor = .lightGray
    }
        
    let myweb = AiriWS()
    @State var txbID = ""
    @State var txbSex = ""
    @State var txbName = ""
    @State var strBlood = ""
    @State var txbLocal = ""
    @State var txbMobile = ""
    @State var txbAddress = ""
    @State var txbAccount = ""
    @State var txbPassword = ""
    @State var showAlertLabel = ""
    @State var txbPasswordCheck = ""
    @State private var birthday = Date()
    @State private var currentPage = 0
    @State private var selectedIndex = 0
    @State private var selectedBlood = 0
    @State private var ShowAlert = false
    @State private var isShowingScanner = false
    
    @Environment(\.dismiss) var dismiss
    
    struct sexRole {
        let sex: String
        let sexEng: String
    }
    let sex = [
        sexRole(sex: "男性", sexEng: "B"),
        sexRole(sex: "女性", sexEng: "G")
    ]
    var blood = ["A", "B", "AB", "O", "不知道"]
    let Headings = ["請問您的姓名", "請選擇您的出生日期", "請問您的性別", "請選擇血型", "市內電話", "行動電話", "現居地址", "請設定您的帳號及密碼"]
    var body: some View {
        VStack {
            TabView(selection: $currentPage){
                ScrollView {
                    LogoStyle(MyW: 165, MyH: 165)
                    VStack{
                        Button{
                            isShowingScanner = true
                        }label: {
                            Label("",systemImage: "qrcode.viewfinder")
                                .font(.system(size: 50))
                        }.sheet(isPresented: $isShowingScanner){
                            CodeScannerView(codeTypes: [.code128], simulatedData: "", completion: handleScan)
                        }
                        FormTextBox(placeholder: "請輸入身分證字號", value: $txbID)
                    }
                }.tag(0)
                
                ScrollView {
                    LogoStyle(MyW: 165, MyH: 165)
                    VStack(alignment: .center){
                        SignTitle(Title: Headings[0])
                        FormTextBox(placeholder: "請輸入姓名", value: $txbName)
                        SignTitle(Title: Headings[1])
                        DatePicker("", selection: $birthday, in: ...Date(), displayedComponents: .date)
                            .labelsHidden()
                            .environment(\.locale, Locale(identifier: "zh_Hant_TW"))
                            .environment(\.calendar, Calendar(identifier: .republicOfChina))
                    }
                }.tag(1)
                
                VStack{
                    LogoStyle(MyW: 165, MyH: 165)
                    VStack{
                        SignTitle(Title: Headings[2])
                        Picker(selection: $selectedIndex) {
                            ForEach(sex.indices, id: \.self){ item in
                                Text(sex[item].sex)
                            }
                        } label: {
                        }
                        .pickerStyle(.wheel)
                        .frame(width: 225, height: 75)
                        .background(Color(.systemGray6))
                        .cornerRadius(30)
                        .shadow(radius: 30)
                        Text("您所選擇的是\(sex[selectedIndex].sex)")
                        Spacer()
                        
                        SignTitle(Title: Headings[3])
                        Picker(selection: $selectedBlood) {
                            ForEach(blood.indices, id: \.self) { item in
                                Text(blood[item])
                                    .font(.title)
                            }
                        } label: {
                        }
                        .pickerStyle(.wheel)
                        .frame(width: 200, height: 80)
                        .background(Color(.systemGray6))
                        .cornerRadius(25)
                        .shadow(radius: 15)
                        Spacer()
                    }
                }.tag(2)
                
                ScrollView {
                    LogoStyle(MyW: 155, MyH: 155)
                    VStack{
                        SignTitle(Title: Headings[4])//電話
                        FormTextBox(placeholder: "請輸入市內電話（非必填）", value: $txbLocal)
                            .keyboardType(.numberPad)
                            .submitLabel(.done)//看是否有此效果
                        SignTitle(Title: Headings[5])//手機
                        FormTextBox(placeholder: "請輸入行動電話", value: $txbMobile)
                        SignTitle(Title: Headings[6])//地址
                        FormTextBox(placeholder: "請輸入現居地址", value: $txbAddress)
                    }
                }.tag(3)
                
                ScrollView {
                    LogoStyle(MyW: 165, MyH: 165)
                    VStack{
                        SignTitle(Title: Headings[7])
                        FormTextBox(placeholder: "請輸入帳號", value: $txbAccount)
                        FormSecureField(passwordText: "請輸入密碼", label: $txbPassword)
                            .padding(12)
                        FormSecureField(passwordText: "請再輸入一次密碼", label: $txbPasswordCheck)
                            .padding(12)
                        Spacer()
                    }
                }.tag(4)
            }.tabViewStyle(PageTabViewStyle(indexDisplayMode: .always))
                .indexViewStyle(PageIndexViewStyle(backgroundDisplayMode: .automatic))
                .animation(.default, value: currentPage)
            
            VStack{
                Button(action:{
                    switch currentPage{
                    case 0:
                        ShowAlert = false
                        if txbID.isEmpty{
                            ShowAlert = true
                            showAlertLabel = "請輸入身分證"
                        }
                        else{currentPage += 1}
                    case 1:
                        ShowAlert = false
                        if txbName.isEmpty{
                            ShowAlert = true
                            showAlertLabel = "請輸入姓名"
                        }
                        else{currentPage += 1}
                    case 3:
                        ShowAlert = false
                        if txbMobile.isEmpty && txbAddress.isEmpty{
                            ShowAlert = true
                            showAlertLabel = "請輸入行動電話及地址"
                        }
                        else{currentPage += 1}
                    case 4:
                        ShowAlert = false
                        if txbAccount.isEmpty || txbPassword.isEmpty{
                            ShowAlert = true
                            showAlertLabel = "請輸入帳號或密碼"
                        }else if txbPasswordCheck.isEmpty{
                            ShowAlert = true
                            showAlertLabel = "請再輸入一次密碼"
                        }else if txbPassword != txbPasswordCheck{
                            ShowAlert = true
                            txbPasswordCheck = ""
                            showAlertLabel = "密碼不相同，請重新輸入密碼"
                        }else{
                            ShowAlert = false
                            if txbID.isEmpty || txbName.isEmpty || txbMobile.isEmpty || txbAddress.isEmpty{
                                ShowAlert = true
                                showAlertLabel = "前面資料有遺漏填寫\n請再檢查一次"
                            }else{
                                let bdString = myweb.dateToString(date: birthday)
                                if blood[selectedBlood] == "不知道"{
                                    strBlood = ""
                                }else{
                                    strBlood = blood[selectedBlood]
                                }
                                let res = myweb.UserSign801(Account: txbAccount, Password: txbPasswordCheck, Name: txbName, Birthday: bdString, Gender: sex[selectedIndex].sexEng, ID: txbID, Blood: strBlood, Local: txbLocal, Mobile: txbMobile, Address: txbAddress)
                                if res == "Insert_OK"{
                                    dismiss()
                                }else{
                                    txbAccount = ""
                                    ShowAlert = true
                                    showAlertLabel = "此帳號已存在！\n請重新設定"
                                }
                            }
                        }
                    default:
                        ShowAlert = false
                        if currentPage < Headings.count-4{
                            currentPage += 1
                        }
                    }
                }){
                    VStack{
                        if ShowAlert{
                            Text("\(showAlertLabel)")
                                .font(.title)
                        }
                        Text(currentPage == Headings.count-4 ? "完成" : "下一步")
                            .font(.system(size: 32))
                            .frame(width: 135)
                            .padding(8)
                            .background(.white)
                            .overlay(RoundedRectangle(cornerRadius: 32)
                                .stroke(Color(.systemGray4), lineWidth: 2))
                    }.padding(.bottom, 5)
                }
                if currentPage < Headings.count-4{
                    Button(action: {
                        dismiss()
                    }){
                        VStack{
                            Divider().background(Color.brown)
                            Text("已經有帳號")
                                .font(.system(size: 25))
                                .foregroundColor(Color(.systemGray3))
                        }
                    }
                }
            }
        }
    }
    func handleScan(result: Result<ScanResult, ScanError>){
        isShowingScanner = false
        switch result{
        case .success(let result):
            txbID = result.string
            print(result.string)
        case .failure(let error):
            print("Scanning failed: \(error.localizedDescription)")
        }
    }
}

struct SignView_Previews: PreviewProvider {
    static var previews: some View {
        SignView()
    }
}

//註冊介面—子標題
struct SignTitle: View {
    let Title: String
    var body: some View {
        VStack{
            VStack{
                Text(Title)
                    .font(.system(size: 32))
            }
        }.padding(.top)
    }
}

//註冊介面—文字方塊
struct FormTextBox: View{
    var placeholder: String = ""
    @Binding var value: String
    var body: some View{
        VStack{
            TextField(placeholder, text: $value)
                .font(.system(size:30, design: .rounded))
                .padding(10)
                .overlay(RoundedRectangle(cornerRadius: 15)
                    .stroke(Color(.systemGray5), lineWidth: 2.5))
        }.padding(12)
    }
}
