//
//  MainView.swift
//  HIM
//
//  Created by MILab on 2022/10/2.
//

import SwiftUI
import UIKit

struct MainView: View {
    @State var TabIndex = 0
    @State private var HomeSelect = false
    @State var navigationLinkActive = false
    
    let User: String
    let myweb = AiriWS()
    var Title = ["生理數據", "居家安全", "空氣品質"]
    
    var phyTitle = ["血壓", "飯前血糖", "飯後血糖", "血脂", "血氧", "心跳"]
    var phyUnit = ["mmHg", "mg/dL", "mg/dL", "mg/dL", "%", "bpm"]
    var phyIntroduce = ["收縮壓小於140\n舒張壓小於90", "小於200mg/dL", "小於100mg/dL", "小於140mg/dL", "95～100%", "60～100bpm"]
    
    var weaTitle = ["溫度", "濕度", "PM₂.₅", "PM₁₀", "一氧化碳"]
    var weaUnit = ["℃", "%", "µg/m³", "µg/m³", "ppm"]
    var weaColor = ["WeaOne", "WeaTwo", "WeaThree", "WeaFour", "WeaFive"]
    
    var body: some View {
        TabView(selection: $TabIndex){
            let PhyNew = MainItem(account: User).map{($0.phyValue)}
            ScrollView {
                HStack{
                    if PhyNew[0] == "無資料"{
                        PHYLabel(txtTitle: "血壓", txtValue: PhyNew[0], txtColor: .black, txtUnit: "", Introduce: phyIntroduce[0], backColor: "PhyOne", txtFSize: 26)
                    }else{
                        let sbpString = PhyNew[0]
                        let SBP = Int(sbpString) ?? 0
                        let dbpString = PhyNew[1]
                        let DBP = Int(dbpString) ?? 0
                        
                        NavigationLink(destination: ItemView(User: User, ItemIndex: 0)) {
                            if SBP >= 140 || DBP >= 90{
                                PHYLabel(txtTitle: "血壓", txtValue: "\(PhyNew[0])／\(PhyNew[1])", txtColor: .red, txtUnit: phyUnit[0], Introduce: phyIntroduce[0], backColor: "PhyOne", txtFSize: 28)
                            }else{
                                PHYLabel(txtTitle: "血壓", txtValue: "\(PhyNew[0])／\(PhyNew[1])", txtColor: .black, txtUnit: phyUnit[0], Introduce: phyIntroduce[0], backColor: "PhyOne", txtFSize: 28)
                            }}.opacity(0.8)
                    }
                    //
                    if PhyNew[2] == "無資料"{
                        PHYLabel(txtTitle: "血脂", txtValue: PhyNew[2], txtColor: .black, txtUnit: "", Introduce: phyIntroduce[1], backColor: "PhyTwo", txtFSize: 28)
                    }else{
                        let acString = PhyNew[2]
                        let AC = Int(acString) ?? 0
                        
                        NavigationLink(destination: ItemView(User: User, ItemIndex: 1)) {
                            if AC >= 200{
                                PHYLabel(txtTitle: "血脂", txtValue: PhyNew[2], txtColor: .red, txtUnit: phyUnit[1], Introduce: phyIntroduce[1], backColor: "PhyTwo", txtFSize: 30)
                            }else{
                                PHYLabel(txtTitle: "血脂", txtValue: PhyNew[2], txtColor: .black, txtUnit: phyUnit[1], Introduce: phyIntroduce[1], backColor: "PhyTwo", txtFSize: 30)
                            }
                        }.opacity(0.8)
                    }
                }.padding(12)
                
                HStack{
                    if PhyNew[3] == "無資料"{
                        PHYLabel(txtTitle: "飯前血糖", txtValue: PhyNew[3], txtColor: .black, txtUnit: "", Introduce: phyIntroduce[2], backColor: "PhyThree", txtFSize: 28)
                    }else{
                        let pcString = PhyNew[3]
                        let PC = Int(pcString) ?? 0
                        
                        NavigationLink(destination: ItemView(User: User, ItemIndex: 2)) {
                            if PC >= 100{
                                PHYLabel(txtTitle: "飯前血糖", txtValue: PhyNew[3], txtColor: .red, txtUnit: phyUnit[2], Introduce: phyIntroduce[2], backColor: "PhyThree", txtFSize: 30)
                            }else{
                                PHYLabel(txtTitle: "飯前血糖", txtValue: PhyNew[3], txtColor: .black, txtUnit: phyUnit[2], Introduce: phyIntroduce[2], backColor: "PhyThree", txtFSize: 30)
                            }
                        }.opacity(0.8)
                    }
                    //
                    if PhyNew[4] == "無資料"{
                        PHYLabel(txtTitle: "飯後血糖", txtValue: PhyNew[4], txtColor: .black, txtUnit: "", Introduce: phyIntroduce[3], backColor: "PhyFour", txtFSize: 28)
                    }else{
                        let tcString = PhyNew[4]
                        let TC = Int(tcString) ?? 0
                        
                        NavigationLink(destination: ItemView(User: User, ItemIndex: 3)) {
                            if TC >= 140{
                                PHYLabel(txtTitle: "飯後血糖", txtValue: PhyNew[4], txtColor: .red, txtUnit: phyUnit[3], Introduce: phyIntroduce[3], backColor: "PhyFour", txtFSize: 30)
                            }else{
                                PHYLabel(txtTitle: "飯後血糖", txtValue: PhyNew[4], txtColor: .black, txtUnit: phyUnit[3], Introduce: phyIntroduce[3], backColor: "PhyFour", txtFSize: 30)
                            }
                        }.opacity(0.8)
                    }
                }.padding(12)
                
                HStack{
                    if PhyNew[5] == "無資料"{
                        PHYLabel(txtTitle: "血氧", txtValue: PhyNew[5], txtColor: .black, txtUnit: "", Introduce: phyIntroduce[4], backColor: "PhyFive", txtFSize: 28)
                    }else{
                        let spo2String = PhyNew[5]
                        let SpO2 = Int(spo2String) ?? 0
                        
                        if SpO2 < 95{
                            PHYLabel(txtTitle: "血氧", txtValue: PhyNew[5], txtColor: .red, txtUnit: phyUnit[4], Introduce: phyIntroduce[4], backColor: "PhyFive", txtFSize: 30)
                        }else{
                            PHYLabel(txtTitle: "血氧", txtValue: PhyNew[5], txtColor: .black, txtUnit: phyUnit[4], Introduce: phyIntroduce[4], backColor: "PhyFive", txtFSize: 30)
                        }
                    }
                    //
                    if PhyNew[6] == "無資料"{
                        PHYLabel(txtTitle: "心跳", txtValue: PhyNew[6], txtColor: .black, txtUnit: "", Introduce: phyIntroduce[5], backColor: "PhySix", txtFSize: 28)
                    }else{
                        let bpmString = PhyNew[6]
                        let BPM = Int(bpmString) ?? 0
                        //
                        NavigationLink(destination: ItemView(User: User, ItemIndex: 4)) {
                            if BPM < 60 || BPM > 100{
                                PHYLabel(txtTitle: "心跳", txtValue: PhyNew[6], txtColor: .red, txtUnit: phyUnit[5], Introduce: phyIntroduce[5], backColor: "PhySix", txtFSize: 30)
                            }else{
                                PHYLabel(txtTitle: "心跳", txtValue: PhyNew[6], txtColor: .black, txtUnit: phyUnit[5], Introduce: phyIntroduce[5], backColor: "PhySix", txtFSize: 30)
                            }
                        }.opacity(0.8)
                    }
                }.padding(12)
            }.tabItem{Label("\(Title[0])",systemImage: "stethoscope")}.tag(0)
            
            HStack {
                if navigationLinkActive {
                    NavigationLink("", destination: HomeSafeView(), isActive: $navigationLinkActive)
                }
                
                VStack(alignment: .center){
                    HStack(alignment: .top){
                        Text("居家安全")
                            .font(.system(size:34))
                            .padding(.top, 10)
                        
                    }
                    TimeString()
                        .padding(.top, 8)
                        .frame(width: 220, height: 40)
                        .foregroundColor(.white)
                        .background(Color("AccentColor"))
                        .cornerRadius(32)
                    Spacer()
                    
                    NavigationLink(destination: HomeSafeView()){
                        Text("偵測中無異常")
                            .font(.system(size:36))
                            .padding(12)
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(Color(.systemGray5),lineWidth: 3)
                            )
                    }
                    Spacer()
                }
            }.tabItem{Label("\(Title[1])",systemImage: "house.fill")}.tag(1)//去留
            
            let WeaNew = MainWeaItem(account: User).map{($0.weaValue)}
            ScrollView{
                //                let returnValue = WeaNew[index]
                HStack {
                    if WeaNew[0] == "無資料"{
                        WEALabel(txtTitle: weaTitle[0], txtValue: WeaNew[0], txtColor: .black, txtUnit: "", Introduce: "舒適：15～27℃\n炎熱：超過27℃\n寒冷：低於15℃", backColor: weaColor[0], txtFSize: 28)
                    }else{
                        let tempString = WeaNew[0]
                        let TEMP = Int(tempString) ?? 0
                        if TEMP > 27 || TEMP < 15{
                            WEALabel(txtTitle: weaTitle[0], txtValue: WeaNew[0], txtColor: .red, txtUnit: weaUnit[0], Introduce: "舒適：15～27℃\n炎熱：超過27℃\n寒冷：低於15℃", backColor: weaColor[0], txtFSize: 28)
                        }else{
                            WEALabel(txtTitle: weaTitle[0], txtValue: WeaNew[0], txtColor: .black, txtUnit: weaUnit[0], Introduce: "舒適：15～27℃\n炎熱：超過27℃\n寒冷：低於15℃", backColor: weaColor[0], txtFSize: 28)
                        }
                    }
                        
                    if WeaNew[1] == "無資料"{
                        WEALabel(txtTitle: weaTitle[1], txtValue: WeaNew[1], txtColor: .black, txtUnit: "", Introduce: "舒適：40～70%", backColor: weaColor[1], txtFSize: 28)
                    }else{
                        let humString = WeaNew[1]
                        let HUM = Int(humString) ?? 0
                        if HUM > 70 || HUM < 40{
                            WEALabel(txtTitle: weaTitle[1], txtValue: WeaNew[1], txtColor: .red, txtUnit: weaUnit[1], Introduce: "舒適：40～70%", backColor: weaColor[1], txtFSize: 28)
                        }else{
                            WEALabel(txtTitle: weaTitle[1], txtValue: WeaNew[1], txtColor: .black, txtUnit: weaUnit[1], Introduce: "舒適：40～70%", backColor: weaColor[1], txtFSize: 28)
                        }
                        
                    }
                }.padding(8)
                HStack {
                    if WeaNew[2] == "無資料"{
                        WEALabel(txtTitle: weaTitle[2], txtValue: WeaNew[2], txtColor: .black, txtUnit: "", Introduce: "日平均低於35.4\(weaUnit[2])", backColor: weaColor[2], txtFSize: 28)
                    }else{
                        let pm25String = WeaNew[2]
                        let PM25 = Double(pm25String) ?? 0
                        if PM25 > 35.4{
                            WEALabel(txtTitle: weaTitle[2], txtValue: WeaNew[2], txtColor: .red, txtUnit: weaUnit[2], Introduce: "日平均低於35.4\(weaUnit[2])", backColor: weaColor[2], txtFSize: 28)
                        }else{
                            WEALabel(txtTitle: weaTitle[2], txtValue: WeaNew[2], txtColor: .black, txtUnit: weaUnit[2], Introduce: "日平均低於35.4\(weaUnit[2])", backColor: weaColor[2], txtFSize: 28)
                        }
                    }
                    
                    if WeaNew[3] == "無資料"{
                        WEALabel(txtTitle: weaTitle[3], txtValue: WeaNew[3], txtColor: .black, txtUnit: "", Introduce: "日平均低於100\(weaUnit[2])", backColor: weaColor[3], txtFSize: 28)
                    }else{
                        let pm10String = WeaNew[3]
                        let PM10 = Int(pm10String) ?? 0
                        if PM10 > 100{
                            WEALabel(txtTitle: weaTitle[3], txtValue: WeaNew[3], txtColor: .red, txtUnit: weaUnit[3], Introduce: "日平均低於100\(weaUnit[2])", backColor: weaColor[3], txtFSize: 28)
                        }else{
                            WEALabel(txtTitle: weaTitle[3], txtValue: WeaNew[3], txtColor: .black, txtUnit: weaUnit[3], Introduce: "日平均低於100\(weaUnit[2])", backColor: weaColor[3], txtFSize: 28)
                        }
                    }
                }.padding(8)

                HStack{
                    if WeaNew[4] == "無資料"{
                        WEALabel(txtTitle: weaTitle[4], txtValue: WeaNew[4], txtColor: .black, txtUnit: "", Introduce: "正常：低於35ppm", backColor: weaColor[4], txtFSize: 28)
                    }else{
                        let coString = WeaNew[4]
                        let CO = Double(coString) ?? 0
                        if CO > 35.0{
                            WEALabel(txtTitle: weaTitle[4], txtValue: WeaNew[4], txtColor: .red, txtUnit: weaUnit[4], Introduce: "正常：低於35ppm", backColor: weaColor[4], txtFSize: 28)
                        }else{
                            WEALabel(txtTitle: weaTitle[4], txtValue: WeaNew[4], txtColor: .black, txtUnit: weaUnit[4], Introduce: "正常：低於35ppm", backColor: weaColor[4], txtFSize: 28)
                        }
                    }
//                    WEALabel(txtTitle: weaTitle[index], txtValue: returnValue, txtUnit: "", Introduce: "", txtColor: weaColor[index], txtFSize: 28)
                }.padding(8)
            }.tabItem{Label("\(Title[2])",systemImage: "thermometer")}.tag(2)
            
        }.task {
            EveryDayNotification()
            //            UserNotification()
        }
        .navigationTitle(Title[TabIndex])
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button(action: {
                    if TabIndex == 1{
                        self.HomeSelect.toggle()
                    }
                }) {
                    if TabIndex == 1{
                        Image(systemName: "line.3.horizontal")
                            .resizable()
                            .frame(height: 25)
                    }else{
                        LogoStyle(MyW: 80, MyH: 80)
                    }
                }
            }
        }
        .actionSheet(isPresented: $HomeSelect){
            ActionSheet(title: Text("功能選單"),
                        message: nil,
                        buttons: [.default(Text("歷史偵測情形")){navigationLinkActive = true},
                                  .cancel(Text("取消"))])
        }
    }
    
    private func EveryDayNotification(){
        var datecom = DateComponents()
        datecom.hour = 8
        datecom.minute = 30
        let trigger = UNCalendarNotificationTrigger(dateMatching: datecom, repeats: true)
        
        let content = UNMutableNotificationContent()
        content.title = "定時新增資料"
        content.subtitle = "各個項目"
        content.body = "早安，今日是新的一天～是否有乖乖量測生理資訊呢，來新增生理數據資料吧"
        content.sound = .default
        
        let categoryIdentifer = "Airi.HIM"
        //
        let laterAction = UNNotificationAction(identifier: "HIM.cancel", title: "稍後提醒")
        let NewItemValue = UNNotificationAction(identifier: "HIM.ItemValue", title: "新增資料", options: [.foreground])
        let category = UNNotificationCategory(identifier: categoryIdentifer, actions: [laterAction, NewItemValue], intentIdentifiers: [], options: [])
        //
        UNUserNotificationCenter.current().setNotificationCategories([category])
        content.categoryIdentifier = categoryIdentifer
        
        let request = UNNotificationRequest(identifier: "HIM", content: content, trigger: trigger)
        UNUserNotificationCenter.current().add(request, withCompletionHandler: nil)
    }
    /*
     private func UserNotification(){
     if phyTitle.count <= 0{
     return
     }
     //
     let randomNum = Int.random(in: 0..<phyTitle.count)
     let suggestedItem = phyTitle[randomNum]
     
     var datecom = DateComponents()
     datecom.hour = 17
     datecom.minute = 05
     let trigger = UNCalendarNotificationTrigger(dateMatching: datecom, repeats: true)
     
     let content = UNMutableNotificationContent()
     content.title = "定時新增資料"
     content.subtitle = "\(suggestedItem)"
     content.body = "想念您囉，今日過得好嗎？是否有乖乖量測生理資訊呢，來新增該筆資料吧"
     content.sound = .default
     
     let categoryIdentifer = "Airi.HIM"
     //
     let laterAction = UNNotificationAction(identifier: "HIM.cancel", title: "稍後提醒")
     let NewItemValue = UNNotificationAction(identifier: "HIM.ItemValue", title: "新增資料", options: [.foreground])
     let category = UNNotificationCategory(identifier: categoryIdentifer, actions: [laterAction, NewItemValue], intentIdentifiers: [], options: [])
     //
     UNUserNotificationCenter.current().setNotificationCategories([category])
     content.categoryIdentifier = categoryIdentifer
     
     let request = UNNotificationRequest(identifier: "UserHIM", content: content, trigger: trigger)
     UNUserNotificationCenter.current().add(request, withCompletionHandler: nil)
     }*/
}

struct MainView_Previews: PreviewProvider {
    static var previews: some View {
        MainView(User: "")//
    }
}



struct TimeString: View {
    let NowTime = Date()
    static let sTimeFormat: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm:ss"
        return formatter
    }()
    var body: some View {
        HStack{
            Text("\(NowTime, formatter: Self.sTimeFormat)")
                .multilineTextAlignment(.center)
                .font(.custom("Satisfy-Regular", size: 40))
        }
    }
}



struct PHYLabel: View{
    let txtTitle: String
    let txtValue: String
    let txtColor: Color
    let txtUnit: String
    let Introduce: String
    let backColor: String
    let txtFSize: CGFloat
    var body: some View{
        VStack(alignment: .leading){
            Text(txtTitle)
                .font(.title)
                .fontWeight(.bold)
                .padding(.top, 8)
                .padding(.leading, 5)
                .padding(.bottom, 15)
            Spacer()
            //
            HStack{
                Text(txtValue)
                    .font(.system(size: txtFSize))
                    .foregroundColor(txtColor)
                    .padding(.leading, 5)
                    .padding(.bottom, 15)
                Text(txtUnit)
            }
            Spacer()
            //
            VStack(alignment: .leading){
                Text("正常值")
                Text(Introduce).font(.system(size: 20))
//                    .padding(.trailing)
            }.frame(width: UIScreen.main.bounds.width/2.4, alignment: .trailing)
            Spacer()
        }.frame(width: UIScreen.main.bounds.width/2.2, height: 200)
            .background(Color(backColor))
            .foregroundColor(.black)
            .cornerRadius(8)
    }
}
struct MainPStocktes{
    let phyValue: String
}
private func MainItem(account: String) -> [MainPStocktes]{
    let myweb = AiriWS()
    let itemValue = [
        myweb.SelectTable(TableName: "Health_Record_Table", User: account, Sample: "SBP"),
        myweb.SelectTable(TableName: "Health_Record_Table", User: account, Sample: "DBP"),
        myweb.SelectTable(TableName: "Health_Record_Table", User: account, Sample: "TC"),
        myweb.SelectTable(TableName: "Health_Record_Table", User: account, Sample: "AC"),
        myweb.SelectTable(TableName: "Health_Record_Table", User: account, Sample: "PC"),      
        myweb.SelectTable(TableName: "Health_Record_Table", User: account, Sample: "SpO2"),
        myweb.SelectTable(TableName: "Health_Record_Table", User: account, Sample: "HR")
    ]
    
    var value: String!
    var stocks = [MainPStocktes]()
    
    for i in 0...itemValue.count-1{
        let returnValue = itemValue[i]
        if returnValue.isEmpty{
            value = "無資料"
        }else{
            value = returnValue[0]//
        }
        let stock = MainPStocktes(phyValue: value)
        stocks.append(stock)
    }
    return stocks
}

struct WEALabel: View{
    let txtTitle: String
    let txtValue: String
    let txtColor: Color
    let txtUnit: String
    let Introduce: String
    let backColor: String
    let txtFSize: CGFloat
    var body: some View{
        VStack(alignment: .leading){
            Text(txtTitle)
                .font(.title)
                .fontWeight(.bold)
                .padding(.top, 8)
                .padding(.leading, 5)
                .padding(.bottom, 15)
            Spacer()
            //
            HStack{
                Text(txtValue)
                    .font(.system(size: txtFSize))
                    .foregroundColor(txtColor)
                    .padding(.leading, 5)
                    .padding(.bottom, 15)
                Text(txtUnit)
            }
            Spacer()
            //
            VStack(alignment: .leading){
                Text(Introduce).font(.system(size: 15))
            }.frame(width: UIScreen.main.bounds.width/2.4, alignment: .trailing)
            Spacer()
        }.frame(width: UIScreen.main.bounds.width/2.2, height: 200)
            .background(Color(backColor))
            .foregroundColor(.black)
            .cornerRadius(8)
    }
}
struct MainWStocktes{
    let weaValue: String
}
private func MainWeaItem(account: String) -> [MainWStocktes]{
    let myweb = AiriWS()
    let itemValue = [
        myweb.SelectTable(TableName: "Air_Table", User: account, Sample: "Temp"),
        myweb.SelectTable(TableName: "Air_Table", User: account, Sample: "RH"),
        myweb.SelectTable(TableName: "Air_Table", User: account, Sample: "PM2.5"),
        myweb.SelectTable(TableName: "Air_Table", User: account, Sample: "PM10"),
        myweb.SelectTable(TableName: "Air_Table", User: account, Sample: "CO")
    ]
    
    var value: String!
    var stocks = [MainWStocktes]()
    
    for i in 0...itemValue.count-1{
        let returnValue = itemValue[i]
        if returnValue.isEmpty{
            value = "無資料"
        }else{
            value = returnValue[0]//
        }
        let stock = MainWStocktes(weaValue: value)
        stocks.append(stock)
    }
    return stocks
}
struct DateTimeString: View {
    let NowDate = Date()
    static let sDateFormat: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy年MM月dd日"
        return formatter
    }()
    var body: some View {
        HStack{
            Text("\(NowDate, formatter: Self.sDateFormat)")
                .multilineTextAlignment(.center)
                .font(.custom("Satisfy-Regular", size: 20))
        }
        .padding(.bottom,3)
    }
}
