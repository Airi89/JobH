//
//  HIMApp.swift
//  HIM
//
//  Created by MILab on 2022/9/27.
//

import SwiftUI
import UserNotifications


@main
struct HIMApp: App {
    @UIApplicationDelegateAdaptor private var appDelegate: AppDelegate
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

final class AppDelegate: UIResponder, UIApplicationDelegate, UNUserNotificationCenterDelegate {
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { (granted, error) in
            
            if granted {
                print("使用者允許通知")
            } else {
                print("使用者不允許通知")
            }
        }
        
        return true
    }
}


