//
//  PersonView.swift
//  HIM
//
//  Created by MILab on 2022/10/12.
//

import SwiftUI



struct PersonView: View {
    let User: String
    let myweb = AiriWS()
    let blood = ["A", "B", "AB", "O"]
    let profession = ["在職", "待業", "失業", "退休"]
    
    @State var work = ""    
    @State var local = ""
    @State var mobile = ""
    @State var address = ""
    @State var picblood = ""
    @State var UpdateText = false
    
    @State private var selectedBlood: Int!
    var body: some View {
        List {
            VStack {
                FormLabelField(label: "市內電話", placeholder: "請輸入市內電話", value: $local)//驗證
                    .keyboardType(.numberPad)
                FormLabelField(label: "行動電話", placeholder: "請輸入行動電話", value: $mobile)//驗證
                    .keyboardType(.numberPad)
                FormLabelField(label: "居家住址", placeholder: "請輸入現居地址", value: $address)
                
                
                
                SignTitle(Title: "請選擇職業別")//OK
                Picker(selection: $work) {
                    ForEach(profession.indices, id: \.self) { item in
                        Text(profession[item]).tag(profession[item])
                            .font(.system(size: 28))
                    }
                } label: {
                }
                .pickerStyle(.wheel)
                .frame(height: 85)
                .background(Color(.systemGray6))
                .cornerRadius(18)
                
                //if sign no selected blood showus
                /*
                 if picblood.isEmpty {
                     SignTitle(Title: "請選擇血型")
                     Picker(selection: $picblood) {
                         ForEach(blood.indices, id: \.self) { item in
                             Text(blood[item])
                                 .font(.system(size: 28))
                         }
                     } label: {

                     }
                     .pickerStyle(.wheel)
                     .frame(height: 75)
                     .background(Color(.systemGray6))
                     .cornerRadius(20)
                 }
                 */
                
                
            }
        }.navigationBarTitle("個人資料")
        
        if picblood.isEmpty {
            SignTitle(Title: "請選擇血型")
            VStack {
                HStack {
                    ForEach(0..<blood.count, id: \.self) { btn in
                        Button(action: {
                            self.selectedBlood = btn
                        }) {
                            Text("\(self.blood[btn])")
                                .padding()
                                .font(.largeTitle)
                                .foregroundColor(.white)
                                .frame(width: 78)
                                .background(self.selectedBlood == btn ? Color.blue : Color.green)
                                .clipShape(Capsule())
                        }
                    }
                }
                Button(action: {
                    self.selectedBlood = nil
                }) {
                    Text("Clear Selection")
                }
            }
        }
        
        if mobile.isEmpty || address.isEmpty {
            Text("請填寫資料！！")
                .foregroundColor(.pink)
        }
        if UpdateText {
            Text("更新成功")
                .font(.title2)
                .fontWeight(.heavy)
                .foregroundColor(.blue)
        }
        
        VStack(alignment: .center) {
            Button {
//                print(blood[selectedBlood])
                if selectedBlood == nil {
                    let res = myweb.UpdateUser801(Account: User, Blood: "", Local: local, Phone: mobile, Address: address, Profession: work)
                    if res == "true"{
                        UpdateText = true
                    }
                }else{
                    let res = myweb.UpdateUser801(Account: User, Blood: blood[selectedBlood], Local: local, Phone: mobile, Address: address, Profession: work)
                    if res == "true"{
                        UpdateText = true
                    }
                }
            }label: {
                BtnStyle(label: "填寫完畢", btnColor: Color(.systemGray6), foreColor: Color("AccentColor"))
            }.disabled(mobile.isEmpty || address.isEmpty)
        }
    }
}

struct PersonView_Previews: PreviewProvider {
    static var previews: some View {
        PersonView(User: "")
    }
}
