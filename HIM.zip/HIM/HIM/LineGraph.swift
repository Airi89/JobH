//
//  LineGraph.swift
//  HIM
//
//  Created by MILab on 2022/12/18.
//

import SwiftUI

struct LineGraph: View {
    var data: [CGFloat]
    //
    var labels: [String]
    
    @State var currentPoint = ""
    @State var offset: CGSize = .zero
    
    @State var showPlot = false
    @State var translation: CGFloat = 0
    //
    let screenWidth = UIScreen.main.bounds.width
    var body: some View {
        GeometryReader{proxy in
            let height = proxy.size.height
            let width = (proxy.size.width) / CGFloat(data.count - 1)//
            
            let maxPoint = (data.max() ?? 0) + 75//100
//            let maxPoint = data.max()
            let points = data.enumerated().compactMap{item -> CGPoint in
                
                let progress = item.element / maxPoint
                
                let pathHeight = progress * height
                
                let pathWidth = width * CGFloat(item.offset)
                
                return CGPoint(x: pathWidth, y: -pathHeight + height)//
            }
            ZStack{
                Path{path in
                    path.move(to: CGPoint(x: 0, y: 0))//0,0
                    path.addLines(points)                    
                }
                .strokedPath(StrokeStyle(lineWidth: 5, lineCap: .round, lineJoin: .round))
                .fill(
                    LinearGradient(colors: [Color.blue, Color.purple], startPoint: .leading, endPoint: .trailing)
                )
            }
            .overlay(
                VStack(spacing: 0){
                    Text(currentPoint)
                        .font((.caption.bold()))
                        .foregroundColor(.white)
                        .padding(.vertical, 6)
                        .padding(.horizontal, 10)
                        .background(Color.pink, in:Capsule())
////                        .offset(x: translation < 10 ? 30 : 0)
////                        .offset(x: translation > (proxy.size.width - 60) ? -30 : 0)
                    
                    
                    Rectangle()
                        .fill(Color.pink)
                        .frame(width: 3, height: 50)
                    
//                    Circle()//
//                        .fill(Color.pink)
//                        .frame(width: 22, height: 22)
//                        .overlay(
//                            Circle()
//                                .fill(Color.white)
//                                .frame(width: 10, height: 10)
//                        )
                }
                    .frame(width: 80, height: 170)
                    .offset(y: 70)
                    .offset(offset),
                alignment: .bottomLeading
            )
            .contentShape(Rectangle())
            .gesture(DragGesture().onChanged({value in
                
                withAnimation{showPlot = true}
                
                let translation = value.location.x - 40
                
                let index = max(min(Int((translation / width).rounded() + 1), data.count - 1), 0)
                
                currentPoint = "\(data[index])"
                
//                offset = CGSize(width: translation, height: 0)
                offset = CGSize(width: points[index].x-40, height: points[index].y - height)
                self.translation = translation
                
            }).onEnded({value in
                withAnimation{showPlot = false}
            }))
        }
        .overlay(
            VStack(alignment: .leading){
                let max = data.max() ?? 0
                let min = data.min() ?? 0
                
                Text(currentPoint)
                    .font(.system(size: 32))
                Spacer()
                HStack{
                    ForEach(labels, id:\.self){label in
                        Text("\(label)")
                            .frame(width:screenWidth/CGFloat(labels.count)-10)
                    }
                }
//                Text("\(Int(max))")

//                Spacer()

//                Text("\(Int(min))")
            }.frame(maxWidth: .infinity, alignment: .leading)
            
        )
        .padding(.horizontal,3)
        
        
    }
}

struct LineGraph_Previews: PreviewProvider {
    static var previews: some View {
        ItemView(User: "")
    }
}
